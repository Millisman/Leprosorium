/* s3emul - "secu3 emulator"
Copyright (C) 2016 andreika. Ukraine, Kiev

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

contacts:
http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <array>

#include "s3emul.h"
#include "port.h"

static uartstate_t uartIn, uartOut;
static s3emul_params p;

bool testPortBridge(const s3emul_params & params)
{
	log("Starting Virtual Port bridge test...\n");

	bool good = true;

	p = params;

	log("* Opening first serial port %s @ %d...\n", p.portOut[Secu].c_str(), p.baudOut[Secu]);
	if (!initPort(BoardOut, p.portOut[Secu], p.baudOut[Secu]))
	{
		log("ERROR!\n");
		good = false;
	}

	log("* Opening second serial port %s @ %d...\n", p.portIn[Ms].c_str(), p.baudIn[Ms]);
	if (!initPort(BoardIn, p.portIn[Ms], p.baudIn[Ms]))
	{
		log("ERROR!\n");
		good = false;
	}

	log("* Testing data transfer...\n");

	const int bufSize = 64;
	uint8_t bufOut[bufSize];
	int i;
	for (i = 0; i < bufSize; i++)
		bufOut[i] = (uint8_t)i;

	writePort(BoardOut, bufOut, bufSize);
	delay(10);
	for (i = 0; i < bufSize; i++)
	{
		uint8_t c;
		int num;
		peekPortByte(BoardIn, &c, &num);
		if (num < 1)
		{
			good = false;
			break;
		}
		if (c != bufOut[i])
		{
			good = false;
			break;
		}
	}
	if (good)
		log("CONNECTION OK!\n");
	else
		log("CONNECTION FAILED!\nPlease run Virtual Serial Port Emulator in 'pair' mode!\n");

	deInitPort(BoardIn);
	deInitPort(BoardOut);

	return good;
}

