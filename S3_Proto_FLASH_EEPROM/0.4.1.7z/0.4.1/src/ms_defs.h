/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MS_DEFS_H
#define MS_DEFS_H


const char RevNum[20] =  {    // interface no.
  "MSII Rev 9.90000   "
};
const char Signature[32] = {            // code version
  "** V2.8  SECU-3i Bridge **"
};
/*
const char RevNum[20] = {    // interface no.
    "SECU Rev 3.00000   "
};
const char Signature[32] = {            // code version
    "** V2.8  SECU-3i Bridge **"
};*/ 

#define NO_TBLES    3
#define NO_FMAPS    16
#define NO_SMAPS    16
#define NO_FRPMS    16
#define NO_SRPMS    16
#define NO_INJ      2
#define NO_TEMPS    16
#define NO_TPS_DOTS   4
#define NO_MAP_DOTS   4
#define NPORT    2
#define NO_COILCHG_PTS  5

#pragma pack(push, 1)

// User inputs - 1 set in flash, 1 in ram
typedef struct {
    uint8_t no_cyl;
    uint8_t no_skip_pulses;      // skip >= n pulses at startup
    uint8_t ICIgnOption;     // Bit 0: Input capture: 0 = falling edge, 1 rising
                     // Bit 1: 1= trigger return mode in cranking; for this
          // mode, set bit 0 to normal edge, then opp.edge used in cranking.
          // trigger return not applicable to EDIS
                     // Bits 2-3: spare
                       // Bits 4-7: 0 = standard - charge coil, spark
                       //           1 = Ford  EDIS option
                       //           2 = EDIS with multispark
    uint8_t spkout_hi_lo;    // Ign Output compare: 0 = spark low (gnd)
    uint8_t max_coil_dur,max_spk_dur,dwellAcc/*DurAcc*/;        // ms x 10

    char dwellVolts/*deltV_table*/[NO_COILCHG_PTS], dwellDuration/*deltDur_table*/[NO_COILCHG_PTS]; // Vx10,msx10
    
    uint8_t RevLimOption;     // 0=none, 1=spark retard, 2=fuel cut
    uint8_t RevLimMaxRtd;     // max amount of spark retard (degx10) (at Rpm2 below)            
    uint8_t PredOpt;          // Option for prediction algorithm for next tach plse
                      //  0=use last time interval
                      //  1=use 1st deriv prediction; 2=use 1st deriv at hi
                      //   rpm, 2nd deriv prediction at lo rpm;
                      //  3=use 2nd deriv prediction always.

    int16_t crankingRPM;    // ?????

    int16_t cold_adv_table[NO_TEMPS];
    int16_t triggerOffset/*adv_offset*/;        // all in deg x 10
    //     adv_offset is no deg(x10) between trigger (Input Capture) and TDC.
    //     It may be +btdc (IC1 to TDC) or -atdc (TDC to IC2).
    //
    //    |               |     |
    //    |               |     |
    //   -|---------------|-----|-
    //   IC1             TDC    IC2
    
    int16_t RevLimRpm1,RevLimRpm2;  // Optn 1:Retard spk by 0 deg at Rpm1 and increase
                           //    to RevLimMaxRtd at Rpm2
                        // Optn 2:Cut fuel above Rpm2, restore below Rpm1

    uint8_t afr_table1[NO_FMAPS][NO_FRPMS];            // afr x 10
    uint8_t afr_table2[NO_FMAPS][NO_FRPMS];            // afr x 10
    uint8_t wueBins/*warmen_table*/[NO_TEMPS];  // % enrichment vs temp
    uint8_t taeBins/*tpsen_table*/[NO_TPS_DOTS]; // accel enrichment pw in .1 ms units vs tpsdot
    uint8_t maeBins/*mapen_table*/[NO_MAP_DOTS]; // accel enrichment pw in .1 ms units vs mapdot
    
    int16_t iacstep_table[NO_TEMPS]; // iac steps / PWM (%)

    uint16_t frpm_table[NO_FRPMS],srpm_table[NO_SRPMS];
    
    int16_t fmap_table[NO_FMAPS],smap_table[NO_SMAPS];      // kpa x 10, 
    
    int16_t tempTable[NO_TEMPS];             // deg x 10 (C or F)
    
    int16_t taeRates/*tpsdot_table*/[NO_TPS_DOTS];        // change in % x 10 per .1 sec
    int16_t maeRates/*mapdot_table*/[NO_MAP_DOTS];        // change in kPa x 10 per .1 sec

    int16_t map0,mapmax,clt0,cltmult,mat0,matmult,tps0,tpsmax,batt0,battmax;
                  // kPa x 10, deg F or C x 10, adc counts, volts x 10
    int16_t ego0,egomult,baro0,baromax,bcor0,bcormult,knock0,knockmax;
                  // afr x 10, kpa x 10, volts x 10

    int16_t Dtpred_Gain;  // %

    uint8_t crankTolerance;  // ?????
    uint8_t asTolerance;  // ?????

    uint8_t PulseTol;   // % tolerance for next input pulse    
    uint8_t IdleCtl;   // idle: 0 = none, 1= solenoid, 2= iac stepper motor
                  //  - enabled only when moving, 3 = iac motor - always enabled.
                   // 4 = Ford pwm.
    uint8_t IACtstep;        // iac stepper motor nominal time between steps (.1 ms units)
    uint8_t IACaccstep;      // iac stepper motor accel/decel step time (.1 ms)-future use
    uint8_t IACminstep/*IACnaccstep*/;     // iac stepper motor no. of accel/decel steps - future use

    uint8_t IACpwm_step; // ??????

    int16_t IACStart;        // no. of steps to send at startup to put stepper motor at reference (wide open) position

    int16_t IdleHyst;     // amount clt temp must move before Idle position is changed
/*
    uint8_t CWU,CWH;  // crank pulsewidths at min, max temps in temp_table (ms x 10)
    uint8_t AWEV;            // after start warmup % enrich add-on value,
    uint8_t AWC;             // after start enrichment no. of cycles

    uint8_t Tpsacold;        // cold (-40F) accel amount in .1 ms units
    uint8_t AccMult;         // cold (-40F) accel multiply factor (%)
    uint8_t TpsThresh;       // tpsdot threshhold for acc/decel enrichment(change in %x10 per .1 sec) 
    uint8_t MapThresh;       // mapdot threshhold for acc/decel enrichment(change in kPax10 per .1 s) 
    uint8_t TpsAsync;        // clock duration (in .1 sec tics) for accel enrichment
    uint8_t TPSDQ;           // deceleration fuel cut option (%)
    int16_t TPSWOT;       // TPS value at WOT (for flood clear) in %x10
*/
    int16_t IACcrankpos; //     = scalar,  S16,    556,             "steps",    1.00000,   0.00000,  0.00, 4000.00,      0 ; * (  2 bytes)
    int16_t IACcrankxt; //      = scalar,  S16,    558,             "sec",      1.00000,   0.00000,  0.00,32767.00,      0 ; * (  2 bytes)
    int16_t IACcoldtmp; //      = scalar,  S16,    560,             "�C",       0.05555,  -320.000, -40.0,  300.0,       1 ; * (  2 bytes)
    int16_t IACcoldpos; //      = scalar,  S16,    562,             "steps",    1.00000,   0.00000,  0.00, 4000.00,      0 ; * (  2 bytes)
    int16_t IACcoldxt; //       = scalar,  S16,    564,             "sec",      1.00000,   0.00000,  0.00,32767.00,      0 ; * (  2 bytes)
    int16_t primePulseCold; //  = scalar,  S16,    566,             "msec",     0.10000,   0.00000,  0.00,   65.00,      1 ; * (  2 bytes)
    int16_t primePulseHot; //   = scalar,  S16,    568,             "msec",     0.10000,   0.00000,  0.00,   65.00,      1 ; * (  2 bytes)
    int16_t crankCold; //       = scalar,  S16,    570,             "msec",     0.10000,   0.00000,  0.00,   65.00,      1 ; * (  1 byte)
    int16_t crankHot; //        = scalar,  S16,    572,             "msec",     0.10000,   0.00000,  0.00,   65.00,      1 ; * (  1 byte)
    int16_t asePctCold; //      = scalar,  S16,    574,             "%",        1.00000,   0.00000,  0.00,  400.00,      0 ; * (  2 bytes)
    int16_t asePctHot; //       = scalar,  S16,    576,             "%",        1.00000,   0.00000,  0.00,  400.00,      0 ; * (  2 bytes)
    int16_t aseCountCold; //    = scalar,  S16,    578,             "cycles",   1.00000,   0.00000,  0.00,32767.00,      0 ; * (  2 bytes)
    int16_t aseCountHot; //     = scalar,  S16,    580,             "cycles",   1.00000,   0.00000,  0.00,32767.00,      0 ; * (  2 bytes)
    uint8_t taeColdA; //        = scalar,  U08,    582,             "msec",     0.10000,   0.00000,  0.00,  25.500,      1 ; * (  1 byte)
    uint8_t taeColdM; //        = scalar,  U08,    583,             "%",        1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t tpsThresh; //       = scalar,  U08,    584,             "%/sec",    1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t mapThresh; //       = scalar,  U08,    585,             "kPa/sec",  1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte) threshold for MAE
    uint8_t taeTime; //         = scalar,  U08,    586,             "sec",      0.10000,   0.00000,  0.00,   25.50,      1 ; * (  1 byte)
    uint8_t tdePct; //          = scalar,  U08,    587,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    int16_t floodClear; //      = scalar,  S16,    588,             "%",        0.10000,   0.00000,  0.00,  100.00,      1 ; * (  2 bytes)

    int16_t TPSOXLimit;      // Max tps value (%x10) where O2 closed loop active

    uint8_t tpsProportion/*Tps_acc_wght*/;    // weight (0-100) to be given to tpsdot for accel enrichment.
                  //  100 - Tps_acc_wght will then be given to mapdot.
    uint8_t baroCorr/*BaroOption*/;      // 0=no baro, 1=baro is 1st reading of map (before cranking),
                  // 2=independent barometer (=> EgoOption < 3)
    uint8_t egoType/*EgoOption*/;       // 0 = no ego;1= nb o2;2=single wbo2;3=dual wbo2. NOTE:
                  //  BaroOption MUST be < 2 if EgoOption = 3
    uint8_t egoCount/*EgoCountCmp*/;     // Ign Pulse counts between when EGO corrections are made
    uint8_t egoDelta/*EgoStep*/;         // % step change for EGO corrections
    uint8_t egoLimit;        // Upper/Lower rail limit (egocorr inside 100 +/- limit)
    uint8_t AFRTarget;       // NBO2 AFR determining rich/ lean
    uint8_t Temp_Units;      // 0= coolant & mat in deg F; 1= deg C

    uint8_t MAFOption; //       = bits  ,  U08,    600,      [0:1], "No MAF",  "MAF Only", "MAF/MAP blend", "MAF Fuel/MAP table index",      ; * 
                    //       = bits  ,  U08,    600,      [4:5], "MAF on MAP pin", "MAF on Baro Pin", "MAF on Knock Pin", "INVALID" ; *
    uint8_t DualSpkOptn; //     = bits  ,  U08,    601,      [0:3], "No Dual Spark", "Dual Tach Inputs", "Falling Cam Sync with Tach or Wheel", "Rising Cam Sync with Tach or Wheel", "Single Crank Wheel Input", "Single Cam Wheel Input", "Dual Inputs, Timing from 1 cam tooth", "M-0 Wheel w/ Falling Crank Sync", "M-0 Wheel w/ Rising Crank Sync", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID" ; * (1 byte)

    int16_t FastIdle;     // fast idle Off temperature (idle_ctl = 1 only)
    int16_t egoTemp;         // min clt temp where ego active

    int16_t egoRPM/*RPMOXLimit*/;      // Min rpm where O2 closed loop is active

    uint16_t ReqFuel;     // fuel pulsewidth (usec) at wide open throttle

    uint8_t divider;    // divide factor for input tach pulses
    uint8_t Alternate;       // option to alternate injector banks
    uint8_t InjOpen;         // Injector open time (.1 ms units)
    uint8_t InjPWMTim;       // Time (.1 ms units) after Inj opening to start pwm
    uint8_t InjPWMPd;        // Inj PWM period (us) - keep between 10-25 KHz (100-40 us)
    uint8_t InjPWMDty;       // Inj PWM duty cycle (%)
    uint8_t BatFac;          // Battery fuel pw correction factor (msx10)
    uint8_t twoStroke/*EngStroke*/;       // 0 = 4 stroke
                  // 1 = 2 stroke     
    uint8_t InjType;         // 0 = port injection
                  // 1 = throttle body
    uint8_t NoInj;           // no. of injectors (1-12)

/*
    uint8_t OddFire1;        // > 0 = odd fire option - smaller angle bet firings (deg)
    uint8_t OddFire2;        // > 0 = odd fire option - larger angle bet firings (deg)
    uint8_t PrimeP;          // priming pulsewidth (.1 ms units)
    uint8_t MapAveno,RpmAveno;   // no. of points (Max of 8) for map, rpm rolling averages
*/
    int16_t OddAng; //          = scalar,  S16,    620,      "degrees",         0.10000,   0.00000,-350.0,  350.00,      1
    uint8_t rpmLF; //           = scalar,  U08,    622,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t mapLF; //           = scalar,  U08,    623,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t tpsLF; //           = scalar,  U08,    624,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t egoLF; //           = scalar,  U08,    625,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t adcLF; //           = scalar,  U08,    626,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t knkLF; //           = scalar,  U08,    627,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t AMCOption; //       = bits,    U08,    628,      [0:1], "Disabled", "RAM Update", "FLASH Update", "INVALID"    ; * (  1 byte)

    uint8_t dual_tble_optn;  // 1 = use dual table option - ve, afr tables for each inj
/*
    uint8_t FuelAlpha;       // option for alpha-N mode: 0=none;1=use map,tps blend algorithm;
                  //   2=same as 1, but don't use kpa multiplier in plsewidth eq.
    uint8_t IgnAlpha;        // option to use map,tps(alphaN) blend algorithm for ignition
*/
    uint8_t algorithm; //       = bits,    U08,    630,      [0:1], "Speed Density", "Blend SD/AlphaN, PW=--f(tps)xVE(tps,rpm)", "Blend SD/AlphaN, PW=--VE(tps,rpm)", "INVALID" ; *
/*
    uint8_t alphDir; //         = bits,    U08,    630,      [4:4],   "Use Above", "Invert Above"                          ; *
    uint8_t alpha_baro_spkadv; // = scalar, U08,   631,      "deg/kPa",         0.01000,   0.00000,  0.00,  255.00,      2 ; * (  1 byte)
*/
    uint8_t IgnAlpha;
    uint8_t AfrAlpha;        // option to use map,tps(alphaN) blend algorithm for WBO2 AFR
/*
    uint8_t cpad1;           // byte pad
*/
    uint8_t AFRStoich; //       = scalar,  U08,    633,             "AFR",      0.10000,   0.00000,  0.00,   20.00,      1 ; * (  1 byte)

    int16_t alpha_lorpm;  // option to use map,tps(alphaN) blend algorithm for fuel
    int16_t alpha_hirpm;     //  use tps if < lorpm; use map if > hirpm; else blend., in which
                  //  case lo, hirpm should be consecutive entries in frpm_table.
                  //    set lorpm=hirpm =0 to use map enrichment only,
                  //    set lorpm =25K to use alpha-N enrichment only,
    int16_t alphaMAPtable[6][6]; // Table of ave map values (kpa x 10) for [tps][rpm]
                  //    pairs. Used only for alpha-N algorithm.
                  //  Allows ve table to retain same ve values
                  //  whether in alpha-N mode or not,
    int16_t amap_tps[6];     // Tps values (% x 10) for alpha_map table

    uint16_t amap_rpm[6];     // Rpm values for alpha_map table
    uint32_t baud;         // baud rate

    int16_t MAPOXLimit;   // Max map value (kPax10) where O2 closed loop active

    uint8_t board_type; //      = scalar,  U08,    740,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t mycan_id; //        = scalar,  U08,    741,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)               
    uint8_t fet_delay; //       = scalar,  U08,    742,             "�sec",     1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t vr_delay; //        = scalar,  U08,    743, "�sec/1000rpm",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)   
    uint8_t ECUType; //         = scalar,  U08,    744, "1=MS-II, 2=MicroSquirt",   1.00000,   0.00000,  0.00,    9.00,  0 ; * (  1 byte)
    uint8_t MapThreshXTD2; //   = scalar,  U08,    745,    "-kpa/sec",          1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t pwImpulse; //       = scalar,  U08,    746,             "msec",     0.10000,   0.00000,  0.00,   25.50,      1 ; * (  1 byte)
    uint8_t impulseSec; //      = scalar,  U08,    747,             "sec",      1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t nImpulse; //        = scalar,  U08,    748,             "",         1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t mapdotSample; //    = scalar,  U08,    749,             "msec",     1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t tpsdotSample; //    = scalar,  U08,    750,             "msec",     1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte) 
    uint8_t ASEHot; //          =   bits,  U08,    751,      [0:0], "Disable ASE on Hot Start", "Enable ASE on Hot Start"
    uint8_t InjStart; //        = scalar,  U08,    752,             "%",        1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte) 
    uint8_t MapThreshXTD; //    = scalar,  U08,    753,             "-kpa/sec", 1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t MapThreshXTA; //    = scalar,  U08,    754,             "kpa/sec",  1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t trendmapLimit; //   = scalar,  U08,    755,             "kpa",      1.00000,   0.00000,  0.00,  255.00,      0 ; * (  1 byte)
    uint8_t psEnabled[7]; //       = array ,  U08,    756,    [    7], "on/off",   1.00000,   0.00000,   0.00,    1.00,     0 ; * (  2 bytes)
    uint8_t psCondition[7][2]; //     = array ,  U08,    763,    [  7x2], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint8_t psConnector[7]; //     = array ,  U08,    777,    [    7], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint8_t psInitValue[7]; //     = array ,  U08,    784,    [    7], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint8_t psPortValue[7]; //     = array ,  U08,    791,    [    7], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint8_t psOutSize[7][2]; //       = array ,  U08,    798,    [  7x2], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint16_t psOutOffset[7][2]; //     = array ,  U16,    812,    [  7x2], "",         1.00000,   0.00000,-128.00,  127.00,     0 ; * (  2 bytes)
    uint16_t psThreshold[7][2]; //     = array ,  U16,    840,    [  7x2], "",         1.00000,   0.00000,-32768.0,32767.0,     0 ; * (  4 bytes)
    uint16_t psHysteresis[7][2]; //    = array ,  U16,    868,    [  7x2], "",         1.00000,   0.00000,-32768.0,32767.0,     0 ; * (  4 bytes)
    uint8_t aeTaperTime; //     = scalar,  U08,    896,             "sec",        0.10000,   0.00000,  0.00,   25.50,      1 ; * (  1 byte)
    uint8_t AFRMult; //         = bits,    U08,    897,      [0:1], "Use Combined VE/AFR table", "Separate VE & AFR table w/ NB EGO", "Separate VE & AFR table w/ WB EGO", "INVALID"  ; * (  1 byte)
    int16_t aeEndPW; //         = scalar,  S16,    898,             "msec",       0.10000,   0.00000,  0.00, 1000.00,      1 ; *
    uint8_t egoAlgorithm; //    = bits  ,  U08,    900,      [0:1], "Simple", "Transport Delay", "PID/Smith Predictor", "INVALID" ; * (  1 byte)
    uint8_t egoKP; //           = scalar,  U08,    901,             "%",        1.00000,   0.00000,  0.00,  100.00,      0 ; * (  1 byte)
    uint8_t egoKI; //           = scalar,  U08,    902,             "%",        1.00000,   0.00000,  0.00,  100.00,      0 ; * (  1 byte)
    uint8_t egoKD; //           = scalar,  U08,    903,             "%",        1.00000,   0.00000,  0.00,  100.00,      0 ; * (  1 byte)
    uint16_t egoKdelay1; //      = scalar,  U16,    904,             "msec",       1.00000,   0.00000,  0.00,   65535,      0 ; * (  2 bytes)
    uint16_t egoKdelay2; //      = scalar,  U16,    906,             "revs",     1.00000,   0.00000,  0.00,   65535,      0 ; * (  2 bytes)
    uint8_t flexFuel; //        = bits  ,  U08,    908,      [0:0], "Disabled", "Enabled"                                  ; * (  1 byte)
    uint8_t prime_delay; //     = scalar,  U08,    909,             "sec",      1.00000,   0.00000,  0.00,     255,      0 ; * (  1 byte)
    uint8_t fuelFreq[2]; //        = array ,  U08,    910,    [    2], "Hz",       1.00000,   0.00000,  0.00,     255,      0 ; * (  2 bytes)
    uint8_t fuelCorr[2]; //        = array ,  U08,    912,    [    2], "%",        1.00000,   0.00000,  0.00,     255,      0 ; * (  2 bytes)
    uint8_t AMCstep; //         = scalar,  U08,    914,             "%",        1.00000,   0.00000,  0.00,     255,      0 ; * (  2 bytes)
    uint8_t AMCdve; //          = scalar,  U08,    915,             "%",        1.00000,   0.00000,  0.00,     255,      0 ; * (  2 bytes)
    uint16_t AMCve_rpm; //       = scalar,  U16,    916,             "RPM",      1.00000,   0.00000,  0.00,15000.00,      0 ; * (  2 bytes)
    uint16_t AMCve_map; //       = scalar,  U16,    918,             "kPa",      0.10000,   0.00000,  0.00,  300.00,      2 ; * (  2 bytes)
    uint16_t AMCramve_dt; //     = scalar,  U16,    920,             "sec",      1.0,       0.0,      0.0,   300.0,       0 ; * (  2 bytes)
    uint16_t AMCT_thresh; //     = scalar,  U16,    922,             "sec",      1.0,       0.0,      0.0,  1800.0,       0 ; * (  2 bytes)
    uint16_t AMCupdate_thresh; //= scalar,  U16,    924,             "events",   1.0,       0.0,      0.0, 30000.0,       0 ; * (  2 bytes)
    uint8_t CWOption; //        = bits  ,  U08,    926,      [0:0], "Two-Point", "Table"                                   ; * (  1 byte )
    uint8_t knkOption; //       = bits  ,  U08,    927,      [0:1], "Disabled", "Safe Mode", "Aggressive Mode", "INVALID"  ; * (  1 byte )
                    //    = bits  ,  U08,    927,      [4:4], "Below threshold", "Above threshold"                   ; *
    uint8_t knk_maxrtd; //      = scalar,  U08,    928,             "deg",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_step1; //       = scalar,  U08,    929,             "deg",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_step2; //       = scalar,  U08,    930,             "deg",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_trtd; //        = scalar,  U08,    931,             "sec",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_tadv; //        = scalar,  U08,    932,             "sec",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_dtble_adv; //   = scalar,  U08,    933,             "deg",      0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t knk_ndet; //        = scalar,  U08,    934,             "knocks",   1.0,       0.0,      0.0,     255,       0 ; * (  1 byte )
    uint8_t pad; //             = scalar,  U08,    935,
    uint16_t knk_maxmap; //      = scalar,  U16,    936,             "kPa",      0.1,       0.0,      0.0,   300.0,       1 ; * (  2 bytes)
    uint16_t knk_lorpm; //       = scalar,  U16,    938,             "rpm",      1.0,       0.0,      0.0,   10000,       0 ; * (  2 bytes)
    uint16_t knk_hirpm; //       = scalar,  U16,    940,             "rpm",      1.0,       0.0,      0.0,   10000,       0 ; * (  2 bytes)
    uint16_t knk_rpm[6]; //         = array ,  U16,    942,    [    6], "rpm",      1.0,       0.0,      0.0,    6000,       0 ; * (  2 bytes)
    uint16_t knk_thresh[6]; //      = array ,  U16,    954,    [    6], "v",        0.01,      0.0,      0.0,    5.00,       2 ; * (  2 bytes)
    uint16_t triggerTeeth; //    = scalar,  U16,    966,             "teeth",    1.0,       0.0,      0.0,     512,       0 ; * (  2 bytes)
    uint8_t No_Miss_Teeth; //   = scalar,  U08,    968,             "teeth",    1.0,       0.0,      0.0,     255,       0 ; * (  1 byte )
    uint8_t No_Skip_Teeth; //   = scalar,  U08,    969,             "teeth",    1.0,       0.0,      0.0,     255,       0 ; * (  1 byte )
    uint8_t Delay_Teeth; //     = scalar,  U08,    970,             "teeth",    1.0,       0.0,      0.0,     255,       0 ; * (  1 byte )
    uint8_t ICISR_tmask; //     = scalar,  U08,    971,             "msec",       0.1,       0.0,      0.0,    25.5,       1 ; * (  1 byte )
    uint8_t ICISR_pmask; //     = scalar,  U08,    972,             "%",        1.0,       0.0,      0.0,     200,       0 ; * (  1 byte )
    uint8_t injTestMode; //     = bits  ,  U08,    973,      [0:1], "Normal Mode", "Test Mode", "Repeat Test", "INVALID"   ;   (  1 byte )
    uint16_t ae_lorpm; //        = scalar,  U16,    974,             "rpm",      1.0,       0.0,      0.0,   10000,       0 ; * (  2 bytes)
    uint16_t ae_hirpm; //        = scalar,  U16,    976,             "rpm",      1.0,       0.0,      0.0,   10000,       0 ; * (  2 bytes)
    int16_t fuelSpkDel[2]; //      = array ,  S16,    978,    [    2], "deg",      0.10000,   0.00000,-45.00,   45.00,      1 ; * (  4 bytes)
    uint16_t injTestSqrts; //    = scalar,  U16,    982,             "squirts",  1,         0,           0,   65000,      0 ;   (  2 bytes)
    uint16_t injTestPW; //       = scalar,  U16,    984,             "msec",     0.001,     0,           0,      65,      3 ;   (  2 bytes)
    uint16_t injTestOffTime; //  = scalar,  U16,    986,             "msec",     0.1,       0,           0,    6500,      1 ;   (  2 bytes)
    uint16_t CID; //             = scalar,  U16,    988,             "cu.in.",   1,         0,           0,     700,      1 ;   (  2 bytes)         
    uint8_t alpha; //           = scalar,  U08,    990,             "%",        1.0,       0.0,        50,     150,      0 ; * (  1 byte ) 
    uint8_t beta; //            = scalar,  U08,    991,             "%",        1.0,       0.0,       0.0,     100,      0 ; * (  1 byte )
    uint8_t gamma; //           = scalar,  U08,    992,             "%",        1.0,       0.0,       0.0,      50,      0 ; * (  1 byte )
    uint8_t acc_synchk; //      = bits,    U08,    993,      [0:1], "Check Only at Steady Speed", "Check Accel and Steady Speed", "Check Decel and Steady Speed", "Check Always" ;  (1 byte)        


} inputs;

typedef struct {
    uint8_t ve_table1[NO_FMAPS][NO_FRPMS];  // %
    uint8_t ve_table2[NO_FMAPS][NO_FRPMS];  // %
    int16_t adv_table[NO_SMAPS][NO_SRPMS];

    uint16_t AMCNBurns; //       = scalar,  U16,    576,             "burns",    1,         0,           0,   65000,      0 ; x (  2 bytes)
    int16_t primePWTable[16]; //    = array ,  S16,    578,    [   10], "msec",       0.10000,   0.00000,  0.00,   65.00,      1 ; * ( 20 bytes)
    int16_t crankPWTable[16]; //    = array ,  S16,    598,    [   10], "msec",       0.10000,   0.00000,  0.00,   65.00,      1 ; * ( 20 bytes)
    int16_t asePctTable[16]; //     = array ,  S16,    618,    [   10], "%",        1.00000,   0.00000,  0.00,  400.00,      0 ; * (  2 bytes)
    int16_t aseCntTable[16]; //     = array ,  S16,    638,    [   10], "cycles",   1.00000,   0.00000,  0.00, 2500.00,      0 ; * (  2 bytes)
    int16_t matTemps[6]; //        = array ,  S16,    658,    [    6], "�C",       0.05555,  -320.000,-40.00,  300.00,      1 ; * ( 12 bytes)
    uint8_t matRetard[6]; //       = array ,  U08,    670,    [    6], "deg",      0.10000,   0.00000,  0.00,    25.5,      1 ; * (  6 bytes)
    uint8_t xTauOption; //      = bits  ,  U08,    676,      [0:1], "Off", "Accel/Decel Only", "Warm-up + Accel/Decel", "INVALID" ; * (  1 byte )
    uint8_t spkN2O; //          = scalar,  U08,    677,             "deg",      0.10000,   0.00000,  0.00,    25.5,      1 ; * (  1 bytes)
    uint16_t XAccTable[5]; //       = array,   U16,    678,     [   5], "%",        0.10000,   0.00000,  0.00,      90,      1 ; * ( 10 bytes)
    uint16_t TauAccTable[5]; //     = array,   U16,    688,     [   5], "msec",     1.00000,   0.00000,  2.00,   20000,      0 ; * ( 10 bytes)
    uint16_t XDecTable[5]; //       = array,   U16,    698,     [   5], "%",        0.10000,   0.00000,  0.00,      90,      1 ; * ( 10 bytes)
    uint16_t TauDecTable[5]; //     = array,   U16,    708,     [   5], "msec",     1.00000,   0.00000,  2.00,   20000,      0 ; * ( 10 bytes)
    uint16_t XTrpms[5]; //          = array,   U16,    718,     [   5], "rpm",      1.00000,   0.00000,  0.00,   10000,      0 ; * ( 10 bytes)
    uint16_t XClt[16]; //            = array,   U16,    728,     [  10], "%",        1.00000,   0.00000,  0.00,     600,      0 ; * ( 20 bytes)
    uint16_t TauClt[16]; //          = array,   U16,    748,     [  10], "%",        1.00000,   0.00000,  0.00,     600,      0 ; * ( 20 bytes)
    uint16_t fRate; //           = scalar,  U16,    768,             "g/s",      0.00100,   0.00000,  0.00,   60000,      3 ; * ( 2 bytes)
    int16_t ipada[47]; //           = array,   S16,    770,     [   47],"",         1.00000,   0.00000,  0.00,     300,      0 ; * ( 96 bytes)
    int16_t baroCorrVals[6]; //    = array ,  S16,    864,    [    6], "kPa",      0.10000,   0.00000,  80.0,  120.00,      1 ; * ( 24 bytes)
    int16_t matCorrTemps[6]; //    = array ,  S16,    876,    [    6], "�C",       0.05555,  -320.000,-40.00,  300.00,      1 ; * ( 12 bytes)
    char baroCorrDelta[6]; //   = array ,  S08,    888,    [    6], "%",        1.00000,   0.00000,-100.0,   120.0,      1 ; * (  6 bytes)
    char matCorrDelta[6]; //    = array ,  S08,    894,    [    6], "%",        1.00000,   0.00000,-100.0,   120.0,      1 ; * (  6 bytes)
    uint16_t MAFFlow[16]; //         = array ,  U16,    900,    [   12], "gram/sec", 0.01000,   0.00000,  0.00,   650.0,      1 ; * ( 24 bytes)      
    uint8_t MAFCor[16]; //          = array ,  U08,    924,    [   12], "%",        1.00000,   0.00000,  0.00,   255.0,      0 ; * ( 12 bytes)   
    uint16_t MAFRPM1; //         = scalar,  U16,    936,             "rpm",      1.00000,   0.00000,  0.00,   10000,      0 ; * (  2 bytes)
    uint16_t MAFRPM2; //         = scalar,  U16,    938,             "rpm",      1.00000,   0.00000,  0.00,   10000,      0 ; * (  2 bytes)
    uint8_t MAFDir; //          = bits  ,  U08,    940,      [0:0], "Use Above", "Invert Above"                             ; * (  1 byte )
    uint8_t VEIXOptn; //        = bits  ,  U08,    941,      [0:1], "Use MAP only", "Adjust MAP for Baro", "Use SAE Pid 43 Abs Load", "INVALID"  ; * (  1 byte )
    uint16_t MatRtdRPMHi; //     = scalar,  U16,    942,             "rpm",      1.00000,   0.00000,  0.00,   10000,      0 ; * (  2 bytes)  
    uint16_t MatRtdRPMLo; //     = scalar,  U16,    944,             "rpm",      1.00000,   0.00000,  0.00,   10000,      0 ; * (  2 bytes)

    int16_t FuelAdj; //         = scalar,  S16,    946,                "",      1.00000,   0.00000,  0.00,   10000,      0 ; Fuel Adj from MShift - not exposed in menus
    int16_t SpkAdj; //          = scalar,  S16,    948,                "",      1.00000,   0.00000,  0.00,   10000,      0 ; Spark Adj from MShift - not exposed in menus 
    int16_t IdleAdj; //         = scalar,  S16,    950,                "",      1.00000,   0.00000,  0.00,   10000,      0 ; Idle Adj from MShift - not exposed in menus 
    int16_t SprAdj; //          = scalar,  S16,    952,                "",      1.00000,   0.00000,  0.00,   10000,      0 ; Spare Adj from MShift - not exposed in menus 

} inputs2;

// rs232 Outputs to pc
typedef struct {
    uint16_t seconds,pw1,pw2,rpm;           // pw in usec
    int16_t adv_deg;                                // adv in deg x 10
    uint8_t squirt,engine,afrtgt1,afrtgt2;    // afrtgt in afr x 10
    /* 
    ; Squirt Event Scheduling Variables - bit fields for "squirt" variable above
    inj1:    equ    0       ; 0 = no squirt; 1 = inj squirting
    inj2:    equ    1

    ; Engine Operating/Status variables - bit fields for "engine" variable above
    ready:  equ     0       ; 0 = engine not ready; 1 = ready to run 
                                                   (fuel pump on or ign plse)
    crank:  equ     1       ; 0 = engine not cranking; 1 = engine cranking
    startw: equ     2       ; 0 = not in startup warmup; 1 = in startw enrichment
    warmup: equ     3       ; 0 = not in warmup; 1 = in warmup
    tpsaen: equ     4       ; 0 = not in TPS acceleration mode; 1 = TPS acceleration mode
    tpsden: equ     5       ; 0 = not in deacceleration mode; 1 = in deacceleration mode
    */

    uint8_t wbo2_en1,wbo2_en2; // from wbo2 - indicates whether wb afr valid
    int16_t baro,map;   // baro - kpa x 10 
                        // map - kpa x 10
                                                     
    int16_t mat,clt;     // mat, clt deg(C/F)x 10
    int16_t tps;                    // tps - % x 10

    int16_t batt,afr1,afr2,knock;                    // batt - vlts x 10
                                                     // ego1,2 - afr x 10
                                                     // knock - volts x 10
    int16_t egocor1,egocor2,aircor,warmcor;                 // all in %
    int16_t tpsaccel,tpsfuelcut,barocor,gammae;             // tpsaccel - acc enrich(.1 ms units)
                                                     // tpsfuelcut - %
                                                     // barcor,gammae - %
    int16_t vecurr1,vecurr2,iacstep,cold_adv_deg;           // vecurr - %
                                                     // iacstep - steps
                                                     // cold_adv_deg - deg x 10
    int16_t tpsdot,mapdot;                                   // tps, map rate of change - %x10/.1 sec,
                                                     // kPax10 / .1 sec
    int16_t coil_dur;                                        // msx10 coil chge set by ecu
/*
    int16_t spare1,spare2,spare3,spare4,spare5,spare6,spare7,spare8,spare9;
*/
    int16_t maf; //              = scalar, S16,   64, "g/sec", 0.010, 0.0
    int16_t kpa; //              = scalar, S16,   66, "kPa",   0.100, 0.0 ; Blend of MAP, MAFMAP and TPS, depends on algorithm
    int16_t fuelCorrection; //   = scalar, S16,   68, "%",     1.000, 0.0 ; Percent alcohol in fuel.
    uint8_t portStatus; //       = scalar, U08,   70, "bit",   1.000, 0.0 ; Spare port status bits
    uint8_t knockRetard; //      = scalar, U08,   71, "deg",   0.100, 0.0
    int16_t xTauFuelCorr1; //    = scalar, S16,   72, "%",     1.000, 0.0
    int16_t egoV1; //            = scalar, S16,   74, "Volts", 0.010, 0.0
    int16_t egoV2; //            = scalar, S16,   76, "Volts", 0.010, 0.0
    int16_t amcUpdates; //       = scalar, S16,   78,  "",     1.000, 0.0
    int16_t kpaix; //            = scalar, S16,   80,  "kPa",  0.100, 0.0
    int16_t xTauFuelCorr2; //    = scalar, S16,   82, "%",     1.000, 0.0
    uint8_t synch; //            = scalar, U08,   84,  "",     1.000, 0.0 
    uint8_t cspare; //           = scalar, U08,   85,  "",     1.000, 0.0 
    int16_t spare1; //           = scalar, S16,   86,  "",     1.000, 0.0
    int16_t spare2; //           = scalar, S16,   88,  "",     1.000, 0.0
    int16_t trig_fix; //         = scalar, S16,   90,  "",     1.000, 0.0
    int16_t spare4; //           = scalar, S16,   92,  "",     1.000, 0.0
    int16_t spare5; //           = scalar, S16,   94,  "",     1.000, 0.0
    int16_t spare6; //           = scalar, S16,   96,  "",     1.000, 0.0
    int16_t spare7; //           = scalar, S16,   98,  "",     1.000, 0.0
    int16_t spare8; //           = scalar, S16,  100,  "",     1.000, 0.0
    int16_t spare9; //           = scalar, S16,  102,  "",     1.000, 0.0
    uint16_t tachCount; //        = scalar, U16,  104,  "",     1.000, 0.0
    uint8_t ospare; //           = scalar, U08,  106,  "",     1.000, 0.0
    uint8_t cksum; //            = scalar, U08,  107,  "",     1.000, 0.0
	uint32_t deltaT; //           = scalar, U32,  108,  "uS",   1.000, 0.0 ; Normalized time between trigger pulses,

} variables;

///////////////////////////////////////////////////////////
// some stuff for S3EMUL...

typedef struct
{
	inputs inpram;
	inputs2 in2ram;
	variables outpc;
} MsParams;

#pragma pack(pop) 

#endif // of MS_DEFS_H
