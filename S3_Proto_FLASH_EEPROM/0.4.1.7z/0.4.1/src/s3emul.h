/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>

#include "s3.h"

#define S3EMUL_TITLE   "S3EMUL"
#define S3EMUL_DESC    " - SECU-3 & MEGASQUIRT bridge/emulator "
#define S3EMUL_VERSION "v0.4.1 (11.03.2017). "
#define S3EMUL_GPL     "Distributed under GPL license.\n(c) 2017 andreika."

typedef struct
{
	size_t offs;
	int size;       // use 1,2,4 for unsigned, and -1,-2,-4 for signed variables
	double coef;
	double add;     // targetValue = sourceValue * coef + add;
} SensorRecord;

typedef struct
{
	char *name;
	int logIdx;
	SensorRecord s3;
	SensorRecord ms;
} SensorParam;

typedef struct
{
	char *name;
	int msTableIdx;
	int s3tableIdx;
	size_t msOffs;
	size_t s3Offs;
	int msTypeSize;
	int s3TypeSize;
	int width, height;
	double coef;
	bool inverseY;
	bool reciprocal;    // 1/x
} TableRT;

typedef struct
{
    std::string portOut[2];
	std::string portIn[2];
	int baudOut[2];
	int baudIn[2];

	std::string fwFileName;
	std::string eepromFileName;
	std::string options;
	std::string logFileName;

	std::string eepromSaveFileName;

	std::string afrFileName[2];	// 0=narrow, 1=wide
	bool emulateWide;
	bool setAfrTarget;
	bool showSliderEgo;
	bool showSliderAfr;
	bool noLogs;

    int rpm;
    int rpm_delay;

    double saveTimePeriod;
    double s3ConnectionTimeout;
	double stoich[2];	// gasoline or gas

} s3emul_params;

const int maxNumFields = 40;    // depends on version!
const double maxDeltaTime = 1.0;    // 5 seconds

typedef struct
{
	double time;
	double fields[maxNumFields];
} CSVRecord;

typedef struct
{
	int threadId;
	std::string str;
} LogRecord;

enum UartPort
{
	// 'secu' mode
	BoardOut,

	// 'ms' bridge mode
	BoardIn,
	SoftOut,
};

enum Mode
{
	Ms = 0,
	Secu,
	Test
};

enum Lambda
{
	Narrow = 0,
	Wide
};

//////////////////////////////////////////////////////////////

inline int round_int(double r)
{
	return (int)((r > 0.0) ? (r + 0.5) : (r - 0.5));
}

template <typename T> inline T Min(T a, T b)
{
	return (a <= b) ? a : b;
}

template <typename T> inline T Max(T a, T b)
{
	return (a >= b) ? a : b;
}

//////////////////////////////////////////////////////////////

void init_s3_uart(uartstate_t &uart, bool isBoard);
void send_s3_client_packet(uartstate_t &uart, struct ecudata_t* d, struct fw_data_t &fw_data, uint8_t send_mode);
void send_s3_master_packet(uartstate_t &uart, struct ecudata_t* d, struct fw_data_t &fw_data, uint8_t send_mode, const PacketParams & params);
int receive_s3_packet(uartstate_t &uart, struct ecudata_t* d, struct fw_data_t &fw_data);
int get_s3_tblIdx(uartstate_t &uart);
int getTableIndex(const struct ecudata_t & d, int curTblIdx);

bool readFW(const std::string & fw, fw_data_t *fd, f_data_t *realtime_table, uint16_t *ce_errors);
void dumpEEPROM(const std::string & fName, ecudata_t *d);

double getTimeInSeconds();
void delay(int ms);

bool initPort(UartPort port, const std::string & p, int baudrate);
void deInitPort(UartPort port);
bool peekPortByte(UartPort port, uint8_t *b, int *num);
void readPort(UartPort port, uint8_t *buf, int numBytes, int *num);
void writePort(UartPort port, uint8_t *buf, int numBytes);

std::string openIni(const std::string & fileName);
std::string getIniString(const std::string & section, const std::string & name, const std::string & defValue, const std::string & cfgName);
int getIniInt(const std::string & section, const std::string & name, int defValue, const std::string & cfgName);
double getIniDouble(const std::string & section, const std::string & name, double defValue, const std::string & cfgName);
void setIniString(const std::string & section, const std::string & name, const std::string & value, const std::string & cfgName);
void setIniInt(const std::string & section, const std::string & name, double value, const std::string & cfgName);

bool readCSVFile(const std::string & fileName, std::vector<CSVRecord> & csvRecords, double *duration);

s3emul_params readParams(const std::string & fname);
void writeParams(const std::string & fname, const s3emul_params & params);

void startGui(bool showSliderEgo, bool showSliderAfr);

int s3Main(Mode mode);

int emulMS(const s3emul_params & params);
int emulS3(const s3emul_params & params);
bool testPortBridge(const s3emul_params & params);

void log(const char *str, ...);
bool saveToLog(Mode mode, const std::string & str);
// void processLog();

const SensorParam *getSensorParams();
const TableRT *getTablesRT();

bool getExiting();
void setExiting(bool);

void overrideEgo(double ego);
void overrideAfr(double afrTarget);
void updateGuiStatus(double afr, double afrTarget);


inline void append_tx_buff(uartstate_t &uart, uint8_t b);
inline void _build_i16h(uartstate_t &uart, uint16_t i);
inline void build_buf8(uartstate_t &uart, uint8_t *buf, uint8_t size);
inline void build_buf16(uartstate_t &uart, const uint16_t *buf, uint8_t size);
inline void _recept_buf16(uartstate_t &uart, uint16_t* ramBuffer, uint8_t size);
inline void _recept_buf8(uartstate_t &uart, uint8_t* ramBuffer, uint8_t size);
inline uint16_t _recept_i16h(uartstate_t &uart);
static uint32_t _recept_i24h(uartstate_t &uart);
static uint32_t _recept_i32h(uartstate_t &uart);
inline uint8_t takeout_rx_buff(uartstate_t &uart);


#define recept_i4h() takeout_rx_buff(uart)
#define recept_i8h() takeout_rx_buff(uart)
#define recept_i16h() _recept_i16h(uart)
#define recept_i24h() _recept_i24h(uart)
#define recept_i32h() _recept_i32h(uart)

#define recept_rb(buf, size) _recept_buf8(uart, buf, size)
#define recept_rs(buf, size) _recept_buf8(uart, buf, size)
#define recept_rw(buf, size) _recept_buf16(uart, buf, size)

#define build_i4h(i)  append_tx_buff(uart, (i))
#define build_i8h(i)  append_tx_buff(uart, (i))

#define build_i16h(i) _build_i16h(uart, (i))
#define build_i24h(i) _build_i24h(uart, (i))
#define build_i32h(i) _build_i32h(uart, (i))

#define build_fs(buf, size) build_buf8(uart, (buf), (size))
#define build_fb(buf, size) build_buf8(uart, (buf), (size))
#define build_rs(buf, size) build_buf8(uart, (buf), (size))
#define build_rb(buf, size) build_buf8(uart, (buf), (size))
#define build_rw(buf, size) build_buf16(uart, (buf), (size))
