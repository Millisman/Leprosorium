/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#include "../s3emul.h"

#ifdef USE_VSP

#include <windows.h>

#ifdef IMPORT_TYPE_LIBRARY
#import "lib/vyserlib.dll"
#else
#include "lib/vyserlib.tlh"
#endif

static vyserlibLib::IVirtualSerialLibraryPtr pLibrary;
static vyserlibLib::IVirtualSerialDevicePtr port_int, port_ext;

bool initVirtualPort(const std::string & portNameExt, std::string &portNameInt)
{
    std::cout << "Creating 'Virtual Serial Ports' connection...\n";
    if (SUCCEEDED(CoInitialize(NULL)))
    {
        try
        {
            if (SUCCEEDED(pLibrary.CreateInstance(__uuidof(vyserlibLib::VirtualSerialLibrary))))
            {
                std::cout << "  * Creating external port " << portNameExt << "...\n";
                _bstr_t vPortName(portNameExt.c_str());
                port_ext = pLibrary->createDevice(vPortName);  // external port
                if (port_ext == nullptr)
                {
                    std::cout << "ERROR! Cannot create external port!\n";
                    return false;
                }

                std::string realPortNameExt = port_ext->portName;
                if (portNameExt != realPortNameExt)
                {
                    std::cout << "ERROR! External port is already in use!\n";
                    return false;
                }

                std::cout << "  * Creating internal port...\n";
                port_int = pLibrary->createDevice();   // create new virtual serial port with automatically-assigned port name
                if (port_int == nullptr)
                {
                    std::cout << "ERROR! Cannot create internal port!\n";
                    return false;
                }

                portNameInt = port_int->portName;
                std::cout << "  * Internal port " << portNameInt << " created!\n";

                std::cout << "  * Creating port bridge...\n";
                port_ext->createBridge(port_int, VARIANT_TRUE); // create a permanent local bridge

                std::cout << "  * ALL OK!\n";

                return true;
            }
        }
        catch (...)
        {
            std::cout << "ERROR! The driver isn't working properly!\nPossibly a FREE version of the driver installed? Use Registered or Trial version ONLY!\n";
            return false;
        }
    }
    std::cout << "ERROR! Cannot find virtual port driver! Please download and install 'Virtual Serial Ports'!\n";
    std::cout << "  http://www.hhdsoftware.com/virtual-serial-ports\n";
    return false;
}

bool deInitVirtualPort()
{
    port_int->deleteDevice();
    port_ext->deleteDevice();

    pLibrary->Release();
    pLibrary = NULL;

    CoUninitialize();

    return true;
}

#endif