/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/time.h>
#endif

double getTimeInSeconds()
{
    double time_in_secs;
#ifdef _WIN32
    static LARGE_INTEGER freq;
    static BOOL use_qpc = QueryPerformanceFrequency(&freq);
    if (use_qpc)
    {
        LARGE_INTEGER t;
        QueryPerformanceCounter(&t);
        time_in_secs = (double)((1000LL * t.QuadPart) / freq.QuadPart) / 1000.0;
    }
    else
        time_in_secs = (double)GetTickCount() / 1000.0;
#else
    struct timeval  tv;
    gettimeofday(&tv, NULL);
    time_in_secs = (double)tv.tv_sec + (double)(tv.tv_usec) / 1000000.0;
#endif

#if 0
    struct timespec tv;
    timespec_get(&tv, TIME_UTC);
    time_in_secs = (double)tv.tv_sec + (double)(tv.tv_usec) / 1000000.0;
#endif

#if 0
    struct timespec tv;
    clock_gettime(CLOCK_REALTIME, &tv);
    time_in_secs = (double)tv.tv_sec + (double)((tv.tv_nsec / 1000000UL) / 1000.0);
#endif

    return time_in_secs;
}

void delay(int ms)
{
#ifdef _WIN32
    Sleep(ms);
#else

#endif
}
