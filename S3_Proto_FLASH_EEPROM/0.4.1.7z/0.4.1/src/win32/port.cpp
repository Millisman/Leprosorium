/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#include "../s3emul.h"

#ifdef _WIN32
#include <windows.h>
#include <atlbase.h>

#define CENUMERATESERIAL_USE_STL
#define NO_CENUMERATESERIAL_USING_SETUPAPI1
#define NO_CENUMERATESERIAL_USING_SETUPAPI2
#include <enumser.h>

static HANDLE uartHandle[3];

bool initPort(UartPort port, const std::string & p, int baudrate)
{
    char pp[256];
    strcpy(pp, "\\\\.\\");
    strcat(pp, p.c_str());

    HANDLE uartPort = CreateFile(pp, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    // Do some basic settings
    DCB serialParams = { 0 };
    serialParams.DCBlength = sizeof(serialParams);

    GetCommState(uartPort, &serialParams);
    serialParams.BaudRate = baudrate;
    serialParams.ByteSize = 8;
    serialParams.StopBits = 1;
    serialParams.Parity = 0;
    SetCommState(uartPort, &serialParams);

    // Set timeouts
    COMMTIMEOUTS timeout = { 0 };
    timeout.ReadIntervalTimeout = 5;
    timeout.ReadTotalTimeoutConstant = 5;
    timeout.ReadTotalTimeoutMultiplier = 1;
    timeout.WriteTotalTimeoutConstant = 5;
    timeout.WriteTotalTimeoutMultiplier = 1;

    SetCommTimeouts(uartPort, &timeout);

	uartHandle[port] = uartPort;

    return (uartPort != nullptr);
}

void deInitPort(UartPort port)
{
	CloseHandle(uartHandle[port]);
}

void readPort(UartPort port, uint8_t *buf, int numBytes, int *num)
{
    int numRead;
	int numTries = 0;
    for (numRead = 0; numRead < numBytes && numTries < 100; )
    {
        int n = 0;
		ReadFile(uartHandle[port], buf + numRead, numBytes - numRead, (DWORD *)&n, NULL);
        numRead += n;
		if (n == 0)
			numTries++;
    }
    *num = numRead;
}

void writePort(UartPort port, uint8_t *buf, int numBytes)
{
    DWORD num;
	WriteFile(uartHandle[port], buf, numBytes, &num, NULL);
}

bool peekPortByte(UartPort port, uint8_t *b, int *num)
{
	return ReadFile(uartHandle[port], b, 1, (DWORD *)num, NULL) == TRUE;
}

std::vector<int> listPorts()
{
	std::vector<int> p;

	CEnumerateSerial::CPortsArray ports;
	CEnumerateSerial::CNamesArray names;

	if (CEnumerateSerial::UsingQueryDosDevice(ports))
	{
		for (size_t i = 0; i < ports.size(); i++)
		{
			p.push_back(ports[i]);
		}
	}
	std::sort(p.begin(), p.end());

	return p;
}

#endif
