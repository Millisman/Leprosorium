/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#include <string>

#include "../s3emul.h"

#ifdef _WIN32
#include <windows.h>

std::string openIni(const std::string & fileName)
{
	char cfgName[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, cfgName);
	strcat(cfgName, "\\");
	strcat(cfgName, fileName.c_str());
	return std::string(cfgName);
}

std::string getIniString(const std::string & section, const std::string & name, const std::string & defValue, const std::string & cfgName)
{
	char tmp[4096];
	GetPrivateProfileStringA(section.c_str(), name.c_str(), defValue.c_str(), tmp, sizeof(tmp), cfgName.c_str());
	return std::string(tmp);
}

int getIniInt(const std::string & section, const std::string & name, int defValue, const std::string & cfgName)
{
	return (int)GetPrivateProfileIntA(section.c_str(), name.c_str(), defValue, cfgName.c_str());
}

double getIniDouble(const std::string & section, const std::string & name, double defValue, const std::string & cfgName)
{
	char tmp[4096], def[32];
	sprintf(def, "%lf", defValue);
	GetPrivateProfileStringA(section.c_str(), name.c_str(), def, tmp, sizeof(tmp), cfgName.c_str());
	return atof(tmp);
}

void setIniString(const std::string & section, const std::string & name, const std::string & value, const std::string & cfgName)
{
	WritePrivateProfileStringA(section.c_str(), name.c_str(), value.c_str(), cfgName.c_str());
}

void setIniInt(const std::string & section, const std::string & name, double value, const std::string & cfgName)
{
	char buf[256];
	if (floor(value) == value)
		sprintf(buf, "%.0lf", value);
	else
		sprintf(buf, "%.2lf", value);
	WritePrivateProfileStringA(section.c_str(), name.c_str(), buf, cfgName.c_str());
}

#endif
