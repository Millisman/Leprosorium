/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   The following code is a derivative work of the code from the SECU-3 project,
   which is licensed GPLv3. This code therefore is also licensed under the terms
   of the GNU Public License, verison 3.

   PORTIONS OF THIS CODE TAKEN FROM:

   SECU-3  - An open source, free engine control unit
   Copyright (C) 2007 Alexey A. Shabelnikov. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org
              email: shabelnikov@secu-3.org
*/

#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <array>

#include "s3emul.h"
#include "port.h"


#define DUMP_EEPROM
//#define PRINT_DEBUG_S3

static struct ecudata_t d;
static struct fw_data_t fw;
static f_data_t realtime_table;
static int curTblIdx = -1;

static uint8_t *dPtr = (uint8_t *)&d;

static std::vector<CSVRecord> logRecords;

static s3emul_params p;
static uartstate_t uart;

static std::string paramsFile;




struct
{
	int mode;
	const char *modeName;
} sendModes[] =
{
	{ CHANGEMODE, "change mode" },
	{ BOOTLOADER, "boot loader" },
	{ TEMPER_PAR, "temperature" },
	{ CARBUR_PAR, "carb." },
	{ IDLREG_PAR, "idling reg." },
	{ ANGLES_PAR, "advance angle" },
	{ FUNSET_PAR, "functions" },
	{ STARTR_PAR, "engine start" },
	{ FNNAME_DAT, "names of func." },
	{ SENSOR_DAT, "sensors data" },
	{ ADCCOR_PAR, "ADC corr." },
	{ ADCRAW_DAT, "raw values" },
	{ CKPS_PAR, "CKP sensor" },
	{ OP_COMP_NC, "suspended op" },
	{ CE_ERR_CODES, "CE codes" },
	{ KNOCK_PAR, "knock chip" },
	{ CE_SAVED_ERR, "CE EEPROM codes" },
	{ FWINFO_DAT, "firmware info" },
	{ MISCEL_PAR, "misc." },
	{ EDITAB_PAR, "RT tables" },
	{ ATTTAB_PAR, "attenuator map" },
	{ RPMGRD_PAR, "RPM grid" },
	{ DBGVAR_DAT, "debug" },
	{ DIAGINP_DAT, "diag. input" },
	{ DIAGOUT_DAT, "diag. output" },
	{ CHOKE_PAR, "choke" },
	{ SECUR_PAR, "security" },
	{ UNIOUT_PAR, "uni.outputs" },
	{ INJCTR_PAR, "injection" },
	{ LAMBDA_PAR, "lambda" },
	{ ACCEL_PAR, "accel.enrichment" },
	{ GASDOSE_PAR, "gas dose" },
	{ SIGINF_DAT, "signature" },
	{ -1, "" }
};

static std::string sendModeName[256];

/////////////////////////////////////////////////////////////////////////////////

//#define UART_DEBUG

// There are several special reserved symbols in binary mode: 0x21, 0x40, 0x0D, 0x0A
#define FIBEGIN  0x21       //!< '!' indicates beginning of the ingoing packet
#define FOBEGIN  0x40       //!< '@' indicates beginning of the outgoing packet
#define FIOEND   0x0D       //!<'\r' indicates ending of the ingoing/outgoing packet
#define FESC     0x0A       //!<'\n' Packet escape (FESC)
// Following bytes are used only in escape sequeces and may appear in the data without any problems
#define TFIBEGIN 0x81       //!< Transposed FIBEGIN
#define TFOBEGIN 0x82       //!< Transposed FOBEGIN
#define TFIOEND  0x83       //!< Transposed FIOEND
#define TFESC    0x84       //!< Transposed FESC




inline uint8_t takeout_rx_buff(uartstate_t &uart)
{
 uint8_t b1 = uart.recv_buf[uart.recv_index++];
 if (b1 == FESC)
 {
  uint8_t b2 = uart.recv_buf[uart.recv_index++];
  if (b2 == (uart.isBoard ? TFIBEGIN : TFOBEGIN))
   return (uart.isBoard ? FIBEGIN : FOBEGIN);
  else if (b2 == TFIOEND)
   return FIOEND;
  else if (b2 == TFESC)
   return FESC;
  return 0; //wrong code
 }
 else
  return b1;
}



inline uint16_t _recept_i16h(uartstate_t &uart)
{
	uint16_t i16;
	_AB(i16, 1) = takeout_rx_buff(uart);
	_AB(i16, 0) = takeout_rx_buff(uart);
	return i16;
}

static uint32_t _recept_i24h(uartstate_t &uart)
{
	uint32_t i = 0;
	i = takeout_rx_buff(uart);
	i = i << 16;
	i |= _recept_i16h(uart);
	return i;
}

static uint32_t _recept_i32h(uartstate_t &uart)
{
	uint32_t i = 0;
	i = _recept_i16h(uart);
	i = i << 16;
	i |= _recept_i16h(uart);
	return i;
}

inline void _recept_buf8(uartstate_t &uart, uint8_t* ramBuffer, uint8_t size)
{
	while (size-- && uart.recv_index < uart.recv_size) *ramBuffer++ = takeout_rx_buff(uart);
}

inline void _recept_buf16(uartstate_t &uart, uint16_t* ramBuffer, uint8_t size)
{
	while (size-- && uart.recv_index < uart.recv_size) *ramBuffer++ = _recept_i16h(uart);
}






inline void build_buf8(uartstate_t &uart, uint8_t *buf, uint8_t size)
{
	while(size--) build_i8h(*buf++);
}

inline void build_buf16(uartstate_t &uart, const uint16_t *buf, uint8_t size)
{
	while(size--) build_i16h(*buf++);
}

////////////////////////////////////////////////////////////////////////////////


inline void append_tx_buff(uartstate_t &uart, uint8_t b)
{
 if (b == (uart.isBoard ? FOBEGIN : FIBEGIN))
 {
  uart.send_buf[uart.send_size++] = FESC;
  uart.send_buf[uart.send_size++] = uart.isBoard ? TFOBEGIN : TFIBEGIN;
 }
 else if ((b) == FIOEND)
 {
  uart.send_buf[uart.send_size++] = FESC;
  uart.send_buf[uart.send_size++] = TFIOEND;
 }
 else if ((b) == FESC)
 {
  uart.send_buf[uart.send_size++] = FESC;
  uart.send_buf[uart.send_size++] = TFESC;
 }
 else
  uart.send_buf[uart.send_size++] = b;
}

inline void _build_i16h(uartstate_t &uart, uint16_t i)
{
	append_tx_buff(uart, _AB((i), 1));
	append_tx_buff(uart, _AB((i), 0));
}

inline void _build_i24h(uartstate_t &uart, uint32_t i)
{
	append_tx_buff(uart, (i >> 16));
	_build_i16h(uart, i);
}

inline void _build_i32h(uartstate_t &uart, uint32_t i)
{
	_build_i16h(uart, i >> 16);
	_build_i16h(uart, i);
}




void initRTTables()
{
	log("* Init params...\n");

	// copy from firmware/eeprom
	memcpy(&d.param, &fw.def_param, sizeof(params_t));

	if (curTblIdx < TABLES_NUMBER_PGM)
	{
		memcpy(&d.tables_ram, &fw.tables[curTblIdx], sizeof(f_data_t)); // from firmware
	}
	else
	{
		memcpy(&d.tables_ram, &realtime_table, sizeof(f_data_t));   // from EEPROM
	}
}




void send_s3_client_packet(uartstate_t &uart, struct ecudata_t* d, struct fw_data_t &fw_data, uint8_t send_mode)
{

    uart.send_size = 0;

    if (send_mode==0)
        send_mode = uart.send_mode;

    uart.send_buf[uart.send_size++] = '@';
    uart.send_buf[uart.send_size++] = send_mode;

    // printf(">%c\n", send_mode);

    switch(send_mode)
    {
        case TEMPER_PAR:
            build_i4h(d->param.tmp_use);
            build_i4h(d->param.vent_pwm);
            build_i4h(d->param.cts_use_map);
            build_i16h(d->param.vent_on);
            build_i16h(d->param.vent_off);
            build_i16h(d->param.vent_pwmfrq);
            break;

        case CARBUR_PAR:
            build_i16h(d->param.ie_lot);
            build_i16h(d->param.ie_hit);
            build_i4h(d->param.carb_invers);
            build_i16h(d->param.fe_on_threshold);
            build_i16h(d->param.ie_lot_g);
            build_i16h(d->param.ie_hit_g);
            build_i8h(d->param.shutoff_delay);
            build_i8h(d->param.tps_threshold);
            build_i16h(d->param.fuelcut_map_thrd);
            build_i16h(d->param.fuelcut_cts_thrd);
            build_i16h(d->param.revlim_lot);
            build_i16h(d->param.revlim_hit);
            break;

        case IDLREG_PAR:
            build_i8h(d->param.idl_flags);   //idling flags
            build_i16h(d->param.ifac1);
            build_i16h(d->param.ifac2);
            build_i16h(d->param.MINEFR);
            build_i16h(d->param.idling_rpm);
            build_i16h(d->param.idlreg_min_angle);
            build_i16h(d->param.idlreg_max_angle);
            build_i16h(d->param.idlreg_turn_on_temp);
            break;

        case ANGLES_PAR:
            build_i16h(d->param.max_angle);
            build_i16h(d->param.min_angle);
            build_i16h(d->param.angle_corr);
            build_i16h(d->param.angle_dec_speed);
            build_i16h(d->param.angle_inc_speed);
            build_i4h(d->param.zero_adv_ang);
            break;

        case FUNSET_PAR:
            build_i8h(d->param.fn_gasoline);
            build_i8h(d->param.fn_gas);
            build_i16h(d->param.map_lower_pressure);
            build_i16h(d->param.map_upper_pressure);
            build_i16h(d->param.map_curve_offset);
            build_i16h(d->param.map_curve_gradient);
            build_i16h(d->param.tps_curve_offset);
            build_i16h(d->param.tps_curve_gradient);
            build_i4h(d->param.load_src_cfg);
            break;

        case STARTR_PAR:
            build_i16h(d->param.starter_off);
            build_i16h(d->param.smap_abandon);
            build_i16h(d->param.inj_cranktorun_time); //fuel injection
            build_i8h(d->param.inj_aftstr_strokes);   //fuel injection
            build_i16h(d->param.inj_prime_cold);      //fuel injection
            build_i16h(d->param.inj_prime_hot);       //fuel injection
            build_i8h(d->param.inj_prime_delay);      //fuel injection
            break;

        case FNNAME_DAT:
            build_i8h(TABLES_NUMBER);
            build_i8h(uart.index);
            build_fs((uart.index < TABLES_NUMBER_PGM ? fw_data.tables[uart.index] : d->tables_ram).name, F_NAME_SIZE);
            ++uart.index;
            if (uart.index >= (TABLES_NUMBER)) uart.index = 0;
            break;

        case SENSOR_DAT:
            build_i16h(d->sens.frequen);           // averaged RPM
            build_i16h(d->sens.map);               // averaged MAP pressure
            build_i16h(d->sens.voltage);           // voltage (avaraged)
            build_i16h(d->sens.temperat);          // coolant temperature
            build_i16h(d->corr.curr_angle);        // advance angle
            build_i16h(d->sens.knock_k);           // knock value
            build_i16h(d->corr.knock_retard);      // knock retard
            build_i8h(d->airflow);                 // index of the map axis curve
            //boolean values
            build_i8h((d->ie_valve   << 0) |       // IE flag
            (d->sens.carb  << 1) |       // carb. limit switch flag
            (d->sens.gas   << 2) |       // gas valve flag
            (d->fe_valve   << 3) |       // power valve flag
            (d->ce_state   << 4) |       // CE flag
            (d->cool_fan   << 5) |       // cooling fan flag
            (d->st_block   << 6) |       // starter blocking flag
            (d->acceleration << 7));     // acceleration enrichment flag
            build_i8h(d->sens.tps);                // TPS (0...100%, x2)
            build_i16h(d->sens.add_i1);            // averaged ADD_I1 voltage
            build_i16h(d->sens.add_i2);            // ADD_I2 voltage
            build_i16h(d->ecuerrors_for_transfer); // CE errors
            build_i8h(d->choke_pos);               // choke position
            build_i8h(d->gasdose_pos);             // gas dosator position
            build_i16h(d->sens.speed);             // vehicle speed (2 bytes)
            build_i24h(d->sens.distance);          // distance (3 bytes)
            build_i16h(d->sens.air_temp);

            //corrections
            build_i16h(d->corr.strt_aalt);         // advance angle from start map
            build_i16h(d->corr.idle_aalt);         // advance angle from idle map
            build_i16h(d->corr.work_aalt);         // advance angle from work map
            build_i16h(d->corr.temp_aalt);         // advance angle from coolant temperature correction map
            build_i16h(d->corr.airt_aalt);         // advance angle from air temperature correction map
            build_i16h(d->corr.idlreg_aac);        // advance angle correction from idling RPM regulator
            build_i16h(d->corr.octan_aac);         // octane correction value

            build_i16h(d->corr.lambda);            // lambda correction
            build_i16h(d->inj_pw);                 // injector pulse width
            build_i16h(d->sens.tpsdot);            // TPS opening/closing speed

            break;

        case ADCCOR_PAR:
            build_i16h(d->param.map_adc_factor);
            build_i32h(d->param.map_adc_correction);
            build_i16h(d->param.ubat_adc_factor);
            build_i32h(d->param.ubat_adc_correction);
            build_i16h(d->param.temp_adc_factor);
            build_i32h(d->param.temp_adc_correction);
            //todo: In the future if we will have a lack of RAM we can split this packet into 2 pieces and decrease size of buffers
            build_i16h(d->param.tps_adc_factor);
            build_i32h(d->param.tps_adc_correction);
            build_i16h(d->param.ai1_adc_factor);
            build_i32h(d->param.ai1_adc_correction);
            build_i16h(d->param.ai2_adc_factor);
            build_i32h(d->param.ai2_adc_correction);
            break;

        case ADCRAW_DAT:
            build_i16h(d->sens.map_raw);
            build_i16h(d->sens.voltage_raw);
            build_i16h(d->sens.temperat_raw);
            build_i16h(d->sens.knock_k);   // <-- knock signal level
            build_i16h(d->sens.tps_raw);
            build_i16h(d->sens.add_i1_raw);
            build_i16h(d->sens.add_i2_raw);
            break;

        case CKPS_PAR:
            build_i4h(d->param.ckps_edge_type);
            build_i4h(d->param.ref_s_edge_type);
            build_i8h(d->param.ckps_cogs_btdc);
            build_i8h(d->param.ckps_ignit_cogs);
            build_i8h(d->param.ckps_engine_cyl);
            build_i4h(d->param.merge_ign_outs);
            build_i8h(d->param.ckps_cogs_num);
            build_i8h(d->param.ckps_miss_num);
            build_i8h(d->param.hall_flags);
            build_i16h(d->param.hall_wnd_width);
            break;

        case OP_COMP_NC:
            build_i16h(d->op_comp_code);
            break;

        case CE_ERR_CODES:
            build_i16h(d->ecuerrors_for_transfer);
            break;

        case KNOCK_PAR:
            build_i4h(d->param.knock_use_knock_channel);
            build_i8h(d->param.knock_bpf_frequency);
            build_i16h(d->param.knock_k_wnd_begin_angle);
            build_i16h(d->param.knock_k_wnd_end_angle);
            build_i8h(d->param.knock_int_time_const);

            build_i16h(d->param.knock_retard_step);
            build_i16h(d->param.knock_advance_step);
            build_i16h(d->param.knock_max_retard);
            build_i16h(d->param.knock_threshold);
            build_i8h(d->param.knock_recovery_delay);
            break;

        case CE_SAVED_ERR:
            build_i16h(d->ecuerrors_saved_transfer);
            break;

        case FWINFO_DAT:
            build_fs(fw_data.fw_signature_info, FW_SIGNATURE_INFO_SIZE);
            build_i32h(fw_data.cddata.config);   // <--compile-time options
            build_i8h(fw_data.cddata.fw_version); // <--version of the firmware
            break;

        case SIGINF_DAT:
            build_fs((uint8_t *)fwinfo, 60);
            break;

        case MISCEL_PAR:
            build_i16h(d->param.uart_divisor);
            build_i8h(d->param.uart_period_t_ms);
            build_i4h(d->param.ign_cutoff);
            build_i16h(d->param.ign_cutoff_thrd);
            build_i8h(d->param.hop_start_cogs);
            build_i8h(d->param.hop_durat_cogs);
            build_i8h(d->param.flpmp_flags);   //fuel pump flags
            break;

        case CHOKE_PAR:
            build_i16h(d->param.sm_steps);
            build_i4h(d->choke_testing);      //fake parameter (actually it is command)
            build_i8h(0);                     //fake parameter, not used in outgoing paket
            build_i8h(d->param.choke_startup_corr);
            build_i16h(d->param.choke_rpm[0]);
            build_i16h(d->param.choke_rpm[1]);
            build_i16h(d->param.choke_rpm_if);
            build_i16h(d->param.choke_corr_time);
            build_i16h(d->param.choke_corr_temp);
            build_i8h(d->param.choke_flags); //choke flags
            break;

        case GASDOSE_PAR:
            build_i16h(d->param.gd_steps);
            build_i4h(d->gasdose_testing);    //fake parameter (actually it is command)
            build_i8h(0);                     //fake parameter, not used in outgoing paket
            build_i8h(d->param.gd_fc_closing);
            build_i16h(d->param.gd_lambda_corr_limit_p);
            build_i16h(d->param.gd_lambda_corr_limit_m);
            break;

        case SECUR_PAR:
            build_i4h(0);
            build_i4h(0);
            build_i8h(d->param.bt_flags);
            build_rb(d->param.ibtn_keys[0], IBTN_KEY_SIZE);  //1st iButton key
            build_rb(d->param.ibtn_keys[1], IBTN_KEY_SIZE);  //2nd iButton key
            break;

        case UNIOUT_PAR:
        { //3 tunable outputs' parameters
            uint8_t oi = 0;
            for (; oi < UNI_OUTPUT_NUMBER; ++oi)
            {
                build_i8h(d->param.uni_output[oi].flags);
                build_i8h(d->param.uni_output[oi].condition1);
                build_i8h(d->param.uni_output[oi].condition2);
                build_i16h(d->param.uni_output[oi].on_thrd_1);
                build_i16h(d->param.uni_output[oi].off_thrd_1);
                build_i16h(d->param.uni_output[oi].on_thrd_2);
                build_i16h(d->param.uni_output[oi].off_thrd_2);
            }
            build_i4h(d->param.uniout_12lf);
            break;
        }

        case INJCTR_PAR:
            build_i8h(d->param.inj_flags);
            build_i8h(d->param.inj_config);
            build_i16h(d->param.inj_flow_rate);
            build_i16h(d->param.inj_cyl_disp);
            build_i32h(d->param.inj_sd_igl_const);
            build_i8h(d->param.ckps_engine_cyl);      //used for calculations on SECU-3 Manager side
            build_i16h(d->param.inj_timing);
            build_i16h(d->param.inj_timing_crk);
            break;

        case LAMBDA_PAR:
            build_i8h(d->param.inj_lambda_str_per_stp);
            build_i8h(d->param.inj_lambda_step_size_p);
            build_i8h(d->param.inj_lambda_step_size_m);
            build_i16h(d->param.inj_lambda_corr_limit_p);
            build_i16h(d->param.inj_lambda_corr_limit_m);
            build_i16h(d->param.inj_lambda_swt_point);
            build_i16h(d->param.inj_lambda_temp_thrd);
            build_i16h(d->param.inj_lambda_rpm_thrd);
            build_i8h(d->param.inj_lambda_activ_delay);
            build_i16h(d->param.inj_lambda_dead_band);
            break;

        case ACCEL_PAR:
            build_i8h(d->param.inj_ae_tpsdot_thrd);
            build_i8h(d->param.inj_ae_coldacc_mult);
            break;

        case EDITAB_PAR:
        {
            build_i8h(uart.state);  //map Id
            switch (uart.state)
            {
                case ETMT_STRT_MAP: //start map
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.f_str, F_STR_POINTS);
                    uart.state = ETMT_IDLE_MAP;
                    break;
                case ETMT_IDLE_MAP: //idle map
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.f_idl, F_IDL_POINTS);
                    uart.state = ETMT_WORK_MAP, uart.wrk_index = 0;
                    break;
                case ETMT_WORK_MAP: //work map
                    build_i8h(uart.wrk_index*F_WRK_POINTS_L);
                    build_rb((uint8_t*)&d->tables_ram.f_wrk[uart.wrk_index][0], F_WRK_POINTS_F);
                    if (uart.wrk_index >= F_WRK_POINTS_L - 1)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_TEMP_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
                case ETMT_TEMP_MAP: //temper. correction.
                    build_i8h(0); // <--not used
                    build_rb((uint8_t*)&d->tables_ram.f_tmp, F_TMP_POINTS);
                    uart.state = ETMT_NAME_STR;
                    break;
                case ETMT_NAME_STR:
                    build_i8h(0); // <--not used
                    build_rs(d->tables_ram.name, F_NAME_SIZE);
                    uart.state = ETMT_VE_MAP, uart.wrk_index = 0;
                    break;

                case ETMT_VE_MAP:
                    build_i8h(uart.wrk_index*INJ_VE_POINTS_L);
                    build_rb((uint8_t*)&d->tables_ram.inj_ve[uart.wrk_index][0], INJ_VE_POINTS_F);
                    if (uart.wrk_index >= INJ_VE_POINTS_L - 1)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_AFR_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
                case ETMT_AFR_MAP:
                    build_i8h(uart.wrk_index*INJ_VE_POINTS_L);
                    build_rb((uint8_t*)&d->tables_ram.inj_afr[uart.wrk_index][0], INJ_VE_POINTS_F);
                    if (uart.wrk_index >= INJ_VE_POINTS_L - 1)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_CRNK_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
                case ETMT_CRNK_MAP:
                    build_i8h(uart.wrk_index*(INJ_CRANKING_LOOKUP_TABLE_SIZE / 2));
                    build_rw((uint16_t*)&d->tables_ram.inj_cranking[uart.wrk_index*(INJ_CRANKING_LOOKUP_TABLE_SIZE / 2)], INJ_CRANKING_LOOKUP_TABLE_SIZE / 2);
                    if (uart.wrk_index >= 1)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_WRMP_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
                case ETMT_WRMP_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_warmup, INJ_WARMUP_LOOKUP_TABLE_SIZE);
                    uart.state = ETMT_DEAD_MAP, uart.wrk_index = 0;
                    break;
                case ETMT_DEAD_MAP:
                    build_i8h(uart.wrk_index*(INJ_DT_LOOKUP_TABLE_SIZE / 4));
                    build_rw((uint16_t*)&d->tables_ram.inj_dead_time[uart.wrk_index*(INJ_DT_LOOKUP_TABLE_SIZE / 4)], (INJ_DT_LOOKUP_TABLE_SIZE / 4));
                    if (uart.wrk_index >= 3)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_IDLR_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
                case ETMT_IDLR_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_iac_run_pos, INJ_IAC_POS_TABLE_SIZE);
                    uart.state = ETMT_IDLC_MAP;
                    break;
                case ETMT_IDLC_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_iac_crank_pos, INJ_IAC_POS_TABLE_SIZE);
                    uart.state = ETMT_AETPS_MAP;
                    break;
                case ETMT_AETPS_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_ae_tps_enr, INJ_AE_TPS_LOOKUP_TABLE_SIZE);
                    build_rb((uint8_t*)&d->tables_ram.inj_ae_tps_bins, INJ_AE_TPS_LOOKUP_TABLE_SIZE);
                    uart.state = ETMT_AERPM_MAP;
                    break;
                case ETMT_AERPM_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_ae_rpm_enr, INJ_AE_RPM_LOOKUP_TABLE_SIZE);
                    build_rb((uint8_t*)&d->tables_ram.inj_ae_rpm_bins, INJ_AE_RPM_LOOKUP_TABLE_SIZE);
                    uart.state = ETMT_AFTSTR_MAP;
                    break;
                case ETMT_AFTSTR_MAP:
                    build_i8h(0); //<--not used
                    build_rb((uint8_t*)&d->tables_ram.inj_aftstr, INJ_AFTSTR_LOOKUP_TABLE_SIZE);
                    uart.state = ETMT_IT_MAP;
                    break;
                case ETMT_IT_MAP:
                    build_i8h(uart.wrk_index*INJ_VE_POINTS_L);
                    build_rb((uint8_t*)&d->tables_ram.inj_timing[uart.wrk_index][0], INJ_VE_POINTS_F);
                    if (uart.wrk_index >= INJ_VE_POINTS_L - 1)
                    {
                        uart.wrk_index = 0;
                        uart.state = ETMT_STRT_MAP;
                    }
                    else
                        ++uart.wrk_index;
                    break;
            }
            break;
        }

        //Transferring of RPM grid
                case RPMGRD_PAR:
                    build_i8h(0); // <--reserved
                    build_fb((uint8_t *)fw_data.exdata.rpm_grid_points, RPM_GRID_SIZE * sizeof(int16_t));
                    break;

                case ATTTAB_PAR:
                {
                    static uint8_t tab_index = 0;
                    build_i8h(tab_index * 16);
                    build_fb(&fw_data.exdata.attenuator_table[tab_index * 16], 16);
                    if (tab_index >= (KC_ATTENUATOR_LOOKUP_TABLE_SIZE / 16) - 1)
                        tab_index = 0;
                    else
                        ++tab_index;
                    break;
                }

                case DBGVAR_DAT:
                    build_i16h(0);
                    build_i16h(0);
                    build_i16h(0);
                    build_i16h(0);
                    break;
    }

    uart.send_buf[uart.send_size++] = '\r';
}






void updateFromLogRecord(double *fields)
{
	const SensorParam *sensorParams = getSensorParams();

	for (int i = 0; sensorParams[i].name != nullptr; i++)
	{
		if (sensorParams[i].logIdx < 0)
			continue;
		assert(sensorParams[i].logIdx < maxNumFields);
		double f = fields[sensorParams[i].logIdx];
		int res = round_int(f * sensorParams[i].s3.coef + sensorParams[i].s3.add);

		switch (sensorParams[i].s3.size)
		{
		case -1: *((int8_t *)&dPtr[sensorParams[i].s3.offs]) = (int8_t)res; break;
		case -2: *((int16_t *)&dPtr[sensorParams[i].s3.offs]) = (int16_t)res; break;
		case -4: *((int32_t *)&dPtr[sensorParams[i].s3.offs]) = (int32_t)res; break;
		case 1: *((uint8_t *)&dPtr[sensorParams[i].s3.offs]) = (uint8_t)res; break;
		case 2: *((uint16_t *)&dPtr[sensorParams[i].s3.offs]) = (uint16_t)res; break;
		case 4: *((uint32_t *)&dPtr[sensorParams[i].s3.offs]) = (uint32_t)res; break;
		}
	}

	int tI = getTableIndex(d, curTblIdx);
	if (tI != curTblIdx)
	{
		curTblIdx = tI;
		initRTTables();
	}
}

int findFwOption(char *opt)
{
	return (strstr(p.options.c_str(), opt) != nullptr) ? 1 : 0;
}

bool initS3Params()
{
	memset(&d, 0, sizeof(d));
	memset(&fw, 0, sizeof(fw));

	int i;
	for (i = 0; i < 256; i++)
		sendModeName[i] = std::string();
	for (i = 0; sendModes[i].mode >= 0; i++)
	{
		sendModeName[sendModes[i].mode] = std::string(sendModes[i].modeName);
	}

	curTblIdx = -1;

	if (p.logFileName[0] == '\0')
	{
		log("Setting parameters from config file...\n");
	}

	strcpy((char *)fw.fw_signature_info, "S3EMUL " S3EMUL_VERSION);
	fw.cddata.config = (findFwOption("DWELL_CONTROL") << 7) | (findFwOption("COOLINGFAN_PWM") << 8) | (findFwOption("REALTIME_TABLES") << 9) | (findFwOption("ICCAVR_COMPILER") << 10) |
		(findFwOption("AVRGCC_COMPILER") << 11) | (findFwOption("DEBUG_VARIABLES") << 12) | (findFwOption("PHASE_SENSOR") << 13) | (findFwOption("PHASED_IGNITION") << 14) |
		(findFwOption("FUEL_PUMP") << 15) | (findFwOption("THERMISTOR_CS") << 16) | (1 << 17) | (findFwOption("DIAGNOSTICS") << 18) | (findFwOption("HALL_OUTPUT") << 19) |
		(findFwOption("REV9_BOARD") << 20) | (findFwOption("STROBOSCOPE") << 21) | (findFwOption("SM_CONTROL") << 22) | (findFwOption("VREF_5V") << 23) |
		(findFwOption("HALL_SYNC") << 24) | (findFwOption("UART_BINARY") << 25) | (findFwOption("CKPS_2CHIGN") << 26) | (1 << 27) |
		(findFwOption("FUEL_INJECT") << 28) | (findFwOption("GD_CONTROL") << 29) | (findFwOption("CARB_AFR") << 30) | (findFwOption("CKPS_NPLUS1") << 31);

	static const int16_t rpg_grid[] = { 600, 720, 840, 990, 1170, 1380, 1650, 1950, 2310, 2730, 3210, 3840, 4530, 5370, 6360, 7500 };
	memcpy(fw.exdata.rpm_grid_points, rpg_grid, sizeof(rpg_grid));

	const SensorParam *sensorParams = getSensorParams();
	std::string cfgName = openIni(paramsFile);

	for (int i = 0; sensorParams[i].name != nullptr; i++)
	{
		if (sensorParams[i].name[0] == '\0')    // empty - not used for config
			continue;
		std::string buf = getIniString("Sensors", sensorParams[i].name, "", cfgName);
		double f = atof(buf.c_str());
		int res = round_int(f * sensorParams[i].s3.coef + sensorParams[i].s3.add);

		switch (sensorParams[i].s3.size)
		{
		case -1: *((int8_t *)&dPtr[sensorParams[i].s3.offs]) = (int8_t)res; break;
		case -2: *((int16_t *)&dPtr[sensorParams[i].s3.offs]) = (int16_t)res; break;
		case -4: *((int32_t *)&dPtr[sensorParams[i].s3.offs]) = (int32_t)res; break;
		case 1: *((uint8_t *)&dPtr[sensorParams[i].s3.offs]) = (uint8_t)res; break;
		case 2: *((uint16_t *)&dPtr[sensorParams[i].s3.offs]) = (uint16_t)res; break;
		case 4: *((uint32_t *)&dPtr[sensorParams[i].s3.offs]) = (uint32_t)res; break;
		}
	}

	return true;
}

void sendToSoft()
{
	writePort(BoardOut, uart.send_buf, uart.send_size);
}

int emulS3(const s3emul_params & params)
{
	log("Starting SECU Emulator!\n");

	p = params;

	log("Opening BOARD serial port %s @ %d...\n", p.portOut[Secu].c_str(), p.baudOut[Secu]);
	if (!initPort(BoardOut, p.portOut[Secu], p.baudOut[Secu]))
	{
		log("ERROR!\n");
		return -4;
	}

	log("Emulating SECU-3 board...\n");

	if (!initS3Params())
	{
		return -2;
	}

	if (p.fwFileName[0] != '\0')
	{
		log("Reading SECU-3 firmware file...\n");
		if (!readFW(p.fwFileName, &fw, &realtime_table, &d.ecuerrors_saved_transfer))
		{
			log("ERROR!\n");
			return false;
		}

		// copy from firmware/eeprom
		memcpy(&d.param, &fw.def_param, sizeof(params_t));
	}

	if (p.eepromFileName[0] != '\0')
	{
		log("Reading SECU-3 EEPROM file...\n");
		if (!readFW(p.eepromFileName, &fw, &realtime_table, &d.ecuerrors_saved_transfer))
		{
			log("ERROR!\n");
			return false;
		}
		//d->ecuerrors_for_transfer = d.ecuerrors_saved_transfer;
	}

	if (p.logFileName[0] != '\0')
	{
		log("Reading log file %s...\n", p.logFileName.c_str());
		double duration;
		logRecords.clear();
		if (!readCSVFile(p.logFileName, logRecords, &duration))
		{
			log("ERROR reading log file!\n");
			return false;
		}

		log("Found %d records. Total duration: %d secs\n", logRecords.size(), round_int(duration));
	} else
	{
		curTblIdx = getTableIndex(d, curTblIdx);
		initRTTables();
	}

	log("Sending/reading packages...\n");

	init_s3_uart(uart, true);

	int pType = 0, sentPType = 0;

	size_t cnt = 0;
	double startTime = getTimeInSeconds();
	double printTime = 0.0;
	int printCnt = 0;

	for (;;)
	{
		if (getExiting())
			break;

		if (logRecords.size() > 0)
		{
			double curTime = getTimeInSeconds() - startTime;
			for (; cnt < logRecords.size() && logRecords[cnt].time < curTime; cnt++)
			{
				updateFromLogRecord(logRecords[cnt].fields);
				send_s3_client_packet(uart, &d, fw, pType);
				sendToSoft();
			}

			if (curTime - printTime > 2.0 || cnt >= logRecords.size())  // every 2 secs
			{
				log("  + %d records added (%d%%)\n", (cnt - printCnt), (cnt * 100 / logRecords.size()));
				printTime = curTime;
				printCnt = cnt;
			}
			if (cnt >= logRecords.size())
				break;
		}
		else
		{
			send_s3_client_packet(uart, &d, fw, pType);
			sendToSoft();
		}
		sentPType = pType;
		pType = 0;
		delay(1);

		// read some data
		int state = 0;
		for (int maxRead = 0; maxRead < UART_RECV_BUFF_SIZE; maxRead++)
		{
			int recv_size;
			uint8_t chr;
			if (!peekPortByte(BoardOut, &chr, &recv_size) || recv_size < 1)
				break;
			switch (state)
			{
			case 0:
				if (chr == '!') // start of a packet
				{
					state = 1;
					uart.recv_index = 0;
				}
				break;
			case 1:
				if (chr == '\r')
				{
					uart.recv_size = uart.recv_index;
					int descr = receive_s3_packet(uart, &d, fw);
					switch (descr)
					{
					case BOOTLOADER:
						log("* WARNING! BOOTLOADER mode not supported!\n");
						break;
					case OP_COMP_NC:
					{
#ifdef PRINT_DEBUG_S3
						log("OP_COMP_NC opcode=%d\n", _AB(d.op_actn_code, 0));
#endif
						int opCode = _AB(d.op_actn_code, 0);
						switch (opCode)
						{
						case OPCODE_READ_FW_SIG_INFO:
							if (sentPType != FWINFO_DAT)
								log("* Sending \"FW Info\" by request...\n");
							pType = FWINFO_DAT;
							break;
						case OPCODE_EEPROM_PARAM_SAVE:
						case OPCODE_SAVE_TABLSET:

							log("* EEPROM save request...\n");
#ifdef DUMP_EEPROM
							log("  Dumping EEPROM to %s\n", p.eepromSaveFileName.c_str());
							dumpEEPROM(p.eepromSaveFileName, &d);
#endif
							break;
						case OPCODE_DIAGNOST_ENTER:
							log("* WARNING! DIAGNOSTIC mode not supported!\n");
							break;
						}
						_AB(d.op_actn_code, 0) = 0; // processed ;-)
						break;
					}
					case EDITAB_PAR:
					{
						log("* Table %d changed!\n", get_s3_tblIdx(uart));
					}
					break;
					case CHANGEMODE:
					{
						static int printedSendMode = -1;
						if (uart.send_mode != printedSendMode)
						{
							log("* Sending \"%s\" by request...\n", sendModeName[uart.send_mode].c_str());
							printedSendMode = uart.send_mode;
						}
						send_s3_client_packet(uart, &d, fw, 0);
						sendToSoft();
						pType = 0;
					}
					break;
					default:
#ifdef PRINT_DEBUG_S3
						log("--%d ('%c') mode='%c'\n", descr, descr, uart.send_mode);
#endif
						;
					}
					maxRead = UART_RECV_BUFF_SIZE;
					break;
				}
				else
				{
					uart.recv_buf[uart.recv_index++] = chr;
				}
				break;
			}
		}
	}

	deInitPort(BoardOut);

	return 0;
}

