/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   The following code is a derivative work of the code from the SECU-3 project,
   which is licensed GPLv3. This code therefore is also licensed under the terms
   of the GNU Public License, verison 3.

   PORTIONS OF THIS CODE TAKEN FROM:

   SECU-3  - An open source, free engine control unit
   Copyright (C) 2007 Alexey A. Shabelnikov. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org
              email: shabelnikov@secu-3.org
*/


#include <iostream>
#include <queue>
#include <mutex>

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include "s3emul.h"
#include "port.h"

#include <nana/gui.hpp>
#include <nana/gui/filebox.hpp>
#include <nana/gui/msgbox.hpp>
#include <nana/gui/place.hpp>
#include <nana/gui/screen.hpp>
#include <nana/gui/widgets/button.hpp>
#include <nana/gui/widgets/checkbox.hpp>
#include <nana/gui/widgets/combox.hpp>
#include <nana/gui/widgets/group.hpp>
#include <nana/gui/widgets/label.hpp>
#include <nana/gui/widgets/panel.hpp>
#include <nana/gui/widgets/slider.hpp>
#include <nana/gui/widgets/textbox.hpp>
#include <nana/threads/pool.hpp>
#include <nana/system/platform.hpp>

//#define DEFERRED_LOGGING

static s3emul_params p;

class DialogFields
{
public:
	nana::combox *port1o;
	nana::combox *baud1o;
	nana::combox *port1i;
	nana::combox *baud1i;
	nana::combox *port2o;
	nana::combox *baud2o;
	nana::textbox *inpFw;
	nana::textbox *inpEe;
	nana::textbox *inpLog;
	nana::textbox *inpSave;
	nana::textbox *inpTo;
	nana::checkbox *cbWide;
	nana::checkbox *cbAfr;
	nana::checkbox *cbSliderEgo;
};

static DialogFields d;

const int numModes = 3;
static nana::place *plc = nullptr;
static nana::textbox *tbox[numModes] = { nullptr };
static nana::button *but[numModes] = { nullptr };
static nana::button *settingsBut = nullptr;
static unsigned long threadIds[numModes] = { 0 };

static nana::form *settingsForm = nullptr;

static bool start[numModes] = { false };
static bool started[numModes] = { false };

static nana::threads::pool *pool = nullptr;

static nana::label *afrLabel;

static std::queue<LogRecord> logQueue;
static std::mutex queueMutex;

static bool noGui = true;

/////////////////////////////////////////////////

void guiLog(const LogRecord & lr)
{
	for (int idx = 0; idx < numModes; idx++)
	{
		if (lr.threadId == threadIds[idx])
		{
			saveToLog((Mode)idx, lr.str);

			if (tbox[idx] != nullptr)
				tbox[idx]->append(lr.str, false);
			break;
		}
	}
}

void log(const char *str, ...)
{
	// \TODO: va_args...
	va_list l;
	va_start(l, str);
	char buf[4096];
	vsnprintf(buf, sizeof(buf), str, l);
	va_end(l);
	if (noGui)
	{
		printf(buf);
		return;
	}

	LogRecord lr;
	lr.str = buf;
	lr.threadId = nana::system::this_thread_id();

#if DEFERRED_LOGGING
	queueMutex.lock();
	logQueue.push(lr);
	queueMutex.unlock();
#else
	guiLog(lr);
#endif
}

// void processLog()
// {
// 	for (;;)
// 	{
// 		if (getExiting())
// 			break;
// 		//std::lock_guard<std::mutex> lock(queueMutex);
// 		queueMutex.lock();
// 		if (logQueue.empty())
// 		{
// 			queueMutex.unlock();
// 			delay(30);
// 			continue;
// 		}
// 		LogRecord lr = logQueue.front();
// 		logQueue.pop();
// 		queueMutex.unlock();
//
// 		guiLog(lr);
// 	}
// }

int startMode(Mode mode)
{
	delay(100);	// TODO: sync with gui
	threadIds[mode] = nana::system::this_thread_id();
	s3Main(mode);
	threadIds[mode] = 0;
	if (but[mode] != nullptr)
		but[mode]->enabled(true);
	return 0;
}

////////////////////////////////////////////////
// Handlers:

int startMs() { return startMode(Ms); }
int startSecu() { return startMode(Secu); }
int startTest() { return startMode(Test); }

void clickButton(Mode mode)
{
	typedef int(*Handler)();
	static Handler handlers[] = { startMs, startSecu, startTest };

	// 'Test' button works only if no other buttons pressed
	if (mode != Test)
	{
		if (settingsBut != nullptr)
			settingsBut->enabled(false);
		if (started[Test])
		{
			plc->erase(*tbox[Test]);
			tbox[Test]->hide();
			started[Test] = false;
		}
	}

	if (!started[mode])
	{
		started[mode] = true;
		(*plc)["tbox"] << *tbox[mode];
		plc->collocate();
	}

	if (but[mode] != nullptr)
	{
		but[mode]->pushed(true);
		but[mode]->enabled(false);
	}
	pool->push(handlers[mode]);
}

/////////////////////////////////////////////////

void clickMs()
{
	clickButton(Ms);
}

void clickSecu()
{
	clickButton(Secu);
}

void applyParams()
{
	p.portOut[Ms] = d.port1o->caption();
	p.baudOut[Ms] = atoi(d.baud1o->caption().c_str());
	p.portIn[Ms] = d.port1i->caption();
	p.baudIn[Ms] = atoi(d.baud1i->caption().c_str());
	p.portOut[Secu] = d.port2o->caption();
	p.baudOut[Secu] = atoi(d.baud2o->caption().c_str());
	d.inpFw->getline(0, p.fwFileName);
	d.inpEe->getline(0, p.eepromFileName);
	d.inpLog->getline(0, p.logFileName);
	p.saveTimePeriod = d.inpSave->to_int();
	p.s3ConnectionTimeout = d.inpTo->to_int();
	p.emulateWide = d.cbWide->checked();
	p.setAfrTarget = d.cbAfr->checked();
	p.showSliderEgo = d.cbSliderEgo->checked();
	writeParams("params.cfg", p);
}

void clickTest()
{
	applyParams();
	if (settingsForm != nullptr)
		settingsForm->close();
	clickButton(Test);
}

void clickOk()
{
	applyParams();
	if (settingsForm != nullptr)
		settingsForm->close();
}

void clickCancel()
{
	if (settingsForm != nullptr)
		settingsForm->close();
}

void clickAbout(const nana::arg_click& ei)
{
	nana::msgbox mb(ei.window_handle, "About S3EMUL...");
	mb.icon(nana::msgbox::icon_information);
	mb << (S3EMUL_TITLE S3EMUL_DESC ".\n");
	mb << "Version " S3EMUL_VERSION ".\n";
	mb << S3EMUL_GPL "\n\n";
	mb << "See readme.txt for details...\n\n";
	mb << "Portions of the code taken from SECU-3 Project\nCopyright(C) 2007 Alexey A.Shabelnikov. Ukraine, Kiev\n";
	mb << "http://secu-3.org";
	mb << "\n\n";
	mb.show();
}

void fillPorts(nana::combox &combo, const std::vector<int> & ports)
{
	combo.clear();
	for (size_t i = 0; i < ports.size(); i++)
		combo.push_back(std::string("COM") + std::to_string(ports[i]));
}

void fillBauds(nana::combox &combo, const int *bauds)
{
	combo.clear();
	for (size_t i = 0; bauds[i] > 0; i++)
		combo.push_back(std::to_string(bauds[i]));
}

void clickBrowse(nana::textbox *tb, const std::string & filterName, const std::string & filterMask)
{
	nana::filebox fb(0, true);
	fb.add_filter(filterName, filterMask);
	fb.add_filter("All Files", "*.*");
	if (fb())
	{
		if (tb != nullptr)
			tb->reset(fb.file());
	}
}

void clickBrowseFw()
{
	clickBrowse(d.inpFw, "SECU Firmware File (*.bin)", "*.bin");
}

void clickBrowseEe()
{
	clickBrowse(d.inpEe, "SECU EEPROM File (*.bin,*.eeprom)", "*.bin;*.eeprom");
}

void clickBrowseLog()
{
	clickBrowse(d.inpLog, "SECU Log File (*.csv)", "*.csv");
}

void clickSettings(const nana::arg_click& ei)
{
	std::vector<int> ports = listPorts();
	int bauds[] = { 9600, 19200, 38400, 57600, 115200, 230400, -1 };

	nana::form fm(ei.window_handle, nana::API::make_center(ei.window_handle, 500, 350),
		nana::appearance(true, false, false, false, false, false, false));
	settingsForm = &fm;
	fm.caption("Settings...");
	nana::place plc(fm);

	nana::button ok(fm, "&Apply");
	ok.events().click(clickOk);
	nana::button cancel(fm, "&Cancel");
	cancel.events().click(clickCancel);

	nana::group grComm(fm, "Communication:", true);
		nana::group grMs(grComm, "MS Bridge:", true);
			nana::group grMsO(grMs, "Output to Software:", true);
				grMsO.div("vertical <weight=30 port1o margin=5><weight=30 baud1o margin=5>");
					d.port1o = new nana::combox (grMsO, p.portOut[Ms]);
					fillPorts(*d.port1o, ports);
					nana::label laOP1(grMsO, "Output Port:");
					grMsO["port1o"] << laOP1 << *d.port1o;
					d.baud1o = new nana::combox(grMsO, std::to_string(p.baudOut[Ms]));
					fillBauds(*d.baud1o, bauds);
					nana::label laOB1(grMsO, "Baud rate:");
					grMsO["baud1o"] << laOB1 << *d.baud1o;

				nana::group grMsI(grMs, "Input from Board:", true);
				grMsI.div("vertical <weight=30 port1i margin=5><weight=30 baud1i margin=5>");
					d.port1i = new nana::combox (grMsI, p.portIn[Ms]);
					fillPorts(*d.port1i, ports);
					nana::label laIP(grMsI, "Input Port:");
					grMsI["port1i"] << laIP << *d.port1i;
					d.baud1i = new nana::combox(grMsI, std::to_string(p.baudIn[Ms]));
					fillBauds(*d.baud1i, bauds);
					nana::label laIB(grMsI, "Baud rate:");
					grMsI["baud1i"] << laIB << *d.baud1i;

				grMs.div("vertical <gr1o weight=80><gr1i weight=80>");
				grMs["gr1o"] << grMsO;
				grMs["gr1i"] << grMsI;

		nana::group grSecu(grComm, "SECU Emulator:");
			grSecu.div("vertical <weight=30 port2o margin=5><weight=30 baud2o margin=5><test weight=20 margin=[0,30,0,30]><files>");
				d.port2o = new nana::combox(grSecu, p.portOut[Secu]);
				fillPorts(*d.port2o, ports);
				nana::label laOP2(grSecu, "Output Port:");
			grSecu["port2o"] << laOP2 << *d.port2o;
				d.baud2o = new nana::combox(grSecu, std::to_string(p.baudOut[Secu]));
				fillBauds(*d.baud2o, bauds);
				nana::label laOB2(grSecu, "Baud rate:");
			grSecu["baud2o"] << laOB2 << *d.baud2o;
				nana::button testBut(grSecu, nana::rectangle(0, 0, 50, 20));
				testBut.caption("Test Virtual Port Bridge");
				testBut.enable_pushed(true);
				testBut.events().click(clickTest);
			grSecu["test"] << testBut;
				nana::group grFiles(grSecu, "Use files:");
				grFiles.div("vertical <fw weight=22 arrange=[60,130,30] margin=2 gap=5><ee weight=22 arrange=[60,130,30] margin=2 gap=5><log weight=22 arrange=[60,130,30] margin=2 gap=5>");
					nana::label laFw(grFiles, "Firmware:");
					d.inpFw = new nana::textbox(grFiles, p.fwFileName);
					d.inpFw->multi_lines(false);
					nana::button fwBut(grFiles, "...");
					fwBut.events().click(clickBrowseFw);
				grFiles["fw"] << laFw << *d.inpFw << fwBut;
					nana::label laEe(grFiles, "EEPROM:");
					d.inpEe = new nana::textbox(grFiles, p.eepromFileName);
					d.inpEe->multi_lines(false);
					nana::button eeBut(grFiles, "...");
					eeBut.events().click(clickBrowseEe);
				grFiles["ee"] << laEe << *d.inpEe << eeBut;
					nana::label laLog(grFiles, "Log file:");
					d.inpLog = new nana::textbox(grFiles, p.logFileName);
					d.inpLog->multi_lines(false);
					nana::button logBut(grFiles, "...");
					logBut.events().click(clickBrowseLog);
					grFiles["log"] << laLog << *d.inpLog << logBut;
			grSecu["files"] << grFiles;

		grComm.div("<gr1><gr2>");
		grComm["gr1"] << grMs;
		grComm["gr2"] << grSecu;

	nana::group grGeneral(fm, "General");
		grGeneral.div("vertical margin=10 <save weight=24 arrange=[190,40]><to weight=24 arrange=[190,40]>");
		nana::label laSave(grGeneral, "Save Time Period, secs:");
		d.inpSave = new nana::textbox(grGeneral, std::to_string((int)p.saveTimePeriod));
		grGeneral["save"] << laSave << *d.inpSave;
		nana::label laTo(grGeneral, "SECU Connection Timeout, secs:");
		d.inpTo = new nana::textbox(grGeneral, std::to_string((int)p.s3ConnectionTimeout));
		grGeneral["to"] << laTo << *d.inpTo;

	nana::group grLambda(fm, "Lambda");
		grLambda.div("vertical margin=10 <wide weight=24><afr weight=24><slider weight=24>");
		d.cbWide = new nana::checkbox(grLambda, "Emulate Wide Lambda Sensor");
		d.cbWide->check(p.emulateWide);
		d.cbAfr = new nana::checkbox(grLambda, "Set AFR Target");
		d.cbAfr->check(p.setAfrTarget);
		d.cbSliderEgo = new nana::checkbox(grLambda, "Show EGO Override Slider");
		d.cbSliderEgo->check(p.showSliderEgo);
		grLambda["wide"] << *d.cbWide;
		grLambda["afr"] << *d.cbAfr;
		grLambda["slider"] << *d.cbSliderEgo;

	plc.div("vertical <gr12 weight=205><<gr3><gr4>><weight=42 margin=[5,50,5,50] buttons gap=20>");
	plc["gr12"] << grComm;
	plc["gr3"] << grGeneral;
	plc["gr4"] << grLambda;
	plc["buttons"] << ok;
	plc["buttons"] << cancel;
	plc.collocate();
	fm.focus();
	nana::API::modal_window(fm);

	delete d.port1o;
	delete d.baud1o;
	delete d.port1i;
	delete d.baud1i;
	delete d.port2o;
	delete d.baud2o;
	delete d.inpFw;
	delete d.inpEe;
	delete d.inpLog;
	delete d.inpSave;
	delete d.inpTo;
	delete d.cbWide;
	delete d.cbAfr;
	delete d.cbSliderEgo;

	settingsForm = nullptr;
}

void changeSliderEgo(const nana::arg_slider & sl)
{
	overrideEgo((double)sl.widget.value());
}

void changeSliderAfr(const nana::arg_slider & sl)
{
	overrideAfr((double)sl.widget.value());
}

void updateGuiStatus(double afr, double afrTarget)
{
	if (afrLabel != nullptr)
	{
		char str[256];
		sprintf(str, "%.1f->%.1f", afr, afrTarget);
		afrLabel->caption(str);
	}
}

/////////////////////////////////////////////////

void startGui(bool showSliderEgo, bool showSliderAfr)
{
	int i;

	nana::form fm(nana::API::make_center(680, 500));
	fm.caption(std::string(S3EMUL_TITLE S3EMUL_DESC S3EMUL_VERSION));
	fm.bgcolor(nana::color(24, 24, 24));

	nana::panel<true> pan(fm, true);
	pan.bgcolor(nana::color(205, 205, 205));
	pan.borderless(false);

	but[Ms] = new nana::button(pan, nana::rectangle(0, 0, 50, 40), true);
	but[Ms]->caption("MS Bridge");
	but[Ms]->enable_pushed(true);
	but[Ms]->events().click(clickMs);

	but[Secu] = new nana::button(pan, nana::rectangle(0, 0, 50, 40), true);
	but[Secu]->caption("SECU Emul");
	but[Secu]->enable_pushed(true);
	but[Secu]->events().click(clickSecu);

	but[Test] = nullptr;

	nana::button settings(pan, nana::rectangle(0, 0, 50, 40), true);
	settings.caption("Settings");
	settings.events().click(clickSettings);
	settingsBut = &settings;

	nana::button about(pan, nana::rectangle(0, 0, 50, 40), true);
	about.caption("About");
	about.events().click(clickAbout);

	for (i = 0; i < numModes; i++)
	{
		tbox[i] = new nana::textbox(fm);
		tbox[i]->bgcolor(nana::color(0, 0, 0));
		tbox[i]->fgcolor(nana::color(255, 255, 255));
		tbox[i]->focus_behavior(nana::textbox::text_focus_behavior::none);
		tbox[i]->editable(false);
		tbox[i]->line_wrapped(false);
		tbox[i]->multi_lines(true);
		//tbox[i]->set_highlight("ERROR", nana::color(255, 0, 0), nana::color(255, 255, 0));
	}

	nana::place fmpl(pan);
	fmpl.div("<tbar gap=10 arrange=100 margin=[5,10]><tright weight=210 margin=[5,10] gap=10>");
	fmpl["tbar"] << (*but[Ms]) << (*but[Secu]);
	fmpl["tright"] << settings;
	fmpl["tright"] << about;
	fmpl.collocate();

	nana::panel<true> status(fm, true);
	status.bgcolor(nana::color(205, 205, 205));
	status.borderless(false);

	nana::slider *sliderEgo = nullptr;
	nana::slider *sliderAfr = nullptr;
	nana::label *afr = nullptr;
	if (showSliderEgo)
	{
		sliderEgo = new nana::slider(fm, nana::rectangle(0, 0, 250, 20), true);
		sliderEgo->maximum(400);
		sliderEgo->move_step(1);
		sliderEgo->value(200);
		sliderEgo->events().value_changed(changeSliderEgo);
	}
	if (showSliderAfr)
	{
		sliderAfr = new nana::slider(fm, nana::rectangle(0, 0, 250, 20), true);
		sliderAfr->maximum(400);
		sliderAfr->move_step(1);
		sliderAfr->value(200);
		sliderAfr->events().value_changed(changeSliderAfr);
	}

	plc = new nana::place(fm);

	if (showSliderEgo || showSliderAfr)
	{
		afr = new nana::label(fm, nana::rectangle(0, 0, 50, 20), true);
		afr->transparent(true);
		afr->text_align(nana::align::right);
		afr->caption("? -> ?");
		afrLabel = afr;

		plc->div("vertical <panel weight=40>|<tbox gap=5>|<status weight=24<<slider vertical weight=90%><gap=5 afr>>>");

		(*plc)["panel"] << pan;
		(*plc)["status"] << status;
		if (sliderEgo != nullptr)
			(*plc)["slider"] << *sliderEgo;
		if (sliderAfr != nullptr)
			(*plc)["slider"] << *sliderAfr;
		(*plc)["afr"] << *afr;
	} else
	{
		plc->div("vertical <panel weight=40>|<tbox gap=5>|<status weight=24>");
		(*plc)["panel"] << pan;
		(*plc)["status"] << status;
	}

	plc->collocate();

	fm.show();

	pool = new nana::threads::pool(4);

#ifdef DEFERRED_LOGGING
	pool->push(processLog);
#endif

	if (start[Test])
		clickButton(Test);
	else
	{
		if (start[Ms])
			clickMs();
		if (start[Secu])
			clickSecu();
	}

	nana::exec();

	setExiting(true);

	for (i = 0; i < numModes; i++)
	{
		if (tbox[i] != nullptr)
		{
			delete tbox[i];
			tbox[i] = nullptr;
		}
	}
	if (afr != nullptr)
		delete afr;
	if (sliderEgo != nullptr)
		delete sliderEgo;
	if (sliderAfr != nullptr)
		delete sliderAfr;
	delete plc;
	delete pool;
}


int __stdcall WinMain(void *hInstance, void *hPrevInstance, char *lpCmdLine, int nCmdShow)
{
	if (strstr(lpCmdLine, "ms") != nullptr)
		start[Ms] = true;
	if (strstr(lpCmdLine, "secu") != nullptr)
		start[Secu] = true;
	if (strstr(lpCmdLine, "test") != nullptr)
		start[Test] = true;

	noGui = false;
	p = readParams("params.cfg");
	startGui(p.showSliderEgo, p.showSliderAfr);
}
