/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   The following code is a derivative work of the code from the SECU-3 project,
   which is licensed GPLv3. This code therefore is also licensed under the terms
   of the GNU Public License, verison 3.

   PORTIONS OF THIS CODE TAKEN FROM:

   SECU-3  - An open source, free engine control unit
   Copyright (C) 2007 Alexey A. Shabelnikov. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org
              email: shabelnikov@secu-3.org
*/

#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <array>

#include <math.h>

#include "s3emul.h"
#include "port.h"
#include "ms_defs.h"

//#define PRINT_DEBUG_MS
#define DUMP_CALIBRATION_TABLES

static MsParams ms = { 0 };
static struct ecudata_t d = { 0 };
static struct fw_data_t fw = { 0 };

static uint8_t *msPtr = (uint8_t *)&ms;
static uint8_t *dPtr = (uint8_t *)&d;

static s3emul_params p;
static uartstate_t uart;

static int curTblIdx = -1;
static bool wideMode = true;
static bool injMode = false, gdMode = false;

static bool readOnlyMode = false;
static bool needsSaving = false;

static double startTime = 0;
static double lastSavedTime = 0;
static double lastReceivedPackedTime = 0;

static double overrideEgoValue = -1.0;
static double overrideAfrValue = -1.0;

static int connLostCnt = 0;

enum S3CommunicationState
{
    Initial = 0,
	ParamFWInfoSent,
    ParamCkpsSent,
    ParamStarterSent,
    ParamFuncSent,
    ParamInjSent,
	ParamGDSent,
    ParamLambdaSent,
    ParamRPMSent,

    TableQuerySent,
    TablesReceiving,
    TablesReceivedFirst,
    TablesReceived,
    Normal
};

static struct
{
	S3CommunicationState state, next;
	int mode;
	char *name;
	bool enabled;
} initStateMachine[] =
{
	{ ParamFWInfoSent,	ParamCkpsSent,		FWINFO_DAT, "FW Info", true },
	{ ParamCkpsSent,	ParamStarterSent,	CKPS_PAR,	"CKPS", true },
	{ ParamStarterSent,	ParamFuncSent,		STARTR_PAR,	"Starter", true },
	{ ParamFuncSent,	ParamInjSent,		FUNSET_PAR, "Func.", true },
	{ ParamInjSent,		ParamGDSent,		INJCTR_PAR, "Injection", true },
	{ ParamGDSent,		ParamLambdaSent,	GASDOSE_PAR, "GasDose", true },
	{ ParamLambdaSent,	ParamRPMSent,		LAMBDA_PAR, "Lambda", true },
	{ ParamRPMSent,		TableQuerySent,		RPMGRD_PAR, "RPM Grid", true },
	{ TableQuerySent,   Initial,			EDITAB_PAR, "", true },
	{ Initial,			Initial,			0,			nullptr, false }
};

#ifdef PRINT_DEBUG_MS
#define DEBUG_MS(d,...) log((const char *)d, __VA_ARGS__)
#else
#define DEBUG_MS(d,...)
#endif

static S3CommunicationState state = Initial;

uint8_t *tables[7] = { nullptr, nullptr, nullptr, nullptr, (uint8_t *)&ms.inpram, (uint8_t *)&ms.in2ram, (uint8_t *)&ms.outpc };
int table_size[7] = { 0, 0, 0, 0, sizeof(ms.inpram), sizeof(ms.in2ram), sizeof(ms.outpc) };

int lambdaType = 0;	// 0=narrow, 1=wide
static std::vector<CSVRecord> afrRecords[2];

void setMSParam(void *ptr, int typeSize, double v, double coef, bool reciprocal)
{
	int res = round_int(reciprocal ? coef / v : v * coef);
	// BIG-ENDIAN!!!
	uint8_t *be = (uint8_t *)ptr;
	switch (typeSize)
	{
	case -1:
	case 1:
		*be = (uint8_t)res; break;
	case -2:
	case 2:
		*be = (res >> 8) & 0xff; *(be + 1) = res & 0xff; break;
	case -4:
	case 4:
		*be = (res >> 24) & 0xff; *(be + 1) = (res >> 16) & 0xff; *(be + 2) = (res >> 8) & 0xff; *(be + 3) = res & 0xff; break;
	}
}

template<typename T, typename M>
void setMSParam(T &ptr, M v, double coef = 1.0, bool reciprocal = false)
{
	setMSParam(&ptr, sizeof(ptr), (double)v, coef, reciprocal);
}

int getMSParam(void *ptr, int typeSize, double coef, bool reciprocal)
{
	double res;
	// BIG-ENDIAN!!!
	uint8_t *be = (uint8_t *)ptr;
	switch (typeSize)
	{
	case -1: res = (int8_t)*be; break;
	case -2: res = ((int16_t)be[0] << 8) | (uint16_t)be[1]; break;
	case -4: res = ((int32_t)be[0] << 24) | ((uint32_t)be[1] << 16) | ((uint32_t)be[2] << 8) | (uint32_t)be[3]; break;
	case 1: res = (uint8_t)*be; break;
	case 2: res = ((uint16_t)be[0] << 8) | (uint16_t)be[1]; break;
	case 4: res = ((uint32_t)be[0] << 24) | ((uint32_t)be[1] << 16) | ((uint32_t)be[2] << 8) | (uint32_t)be[3]; break;
	}
	return round_int(reciprocal ? coef / res : res / coef);
}

void setMSTable(void *msPtr, int msTypeSize, void *s3Ptr, int s3TypeSize, int w, int h, double coef = 1.0, bool reciprocal = false, bool inverseY = true)
{
	for (int ix = 0; ix < w; ix++)
	{
		for (int iy = 0; iy < h; iy++)
		{
			double v;
			int s3Offs = inverseY ? (h - 1 - iy) * w + ix : iy * w + ix;
			switch (s3TypeSize)
			{
			case -1: v = ((int8_t *)s3Ptr)[s3Offs]; break;
			case -2: v = ((int16_t *)s3Ptr)[s3Offs]; break;
			case -4: v = ((int32_t *)s3Ptr)[s3Offs]; break;
			case 1: v = ((uint8_t *)s3Ptr)[s3Offs]; break;
			case 2: v = ((uint16_t *)s3Ptr)[s3Offs]; break;
			case 4: v = ((uint32_t *)s3Ptr)[s3Offs]; break;
			}
			setMSParam((uint8_t *)msPtr + (iy * w + ix) * abs(msTypeSize), msTypeSize, v, coef, reciprocal);
		}
	}
}

void getMSTable(void *msPtr, int msTypeSize, void *s3Ptr, int s3TypeSize, int w, int h, double coef = 1.0, bool reciprocal = false, bool inverseY = true)
{
	for (int ix = 0; ix < w; ix++)
	{
		for (int iy = 0; iy < h; iy++)
		{
			int res = getMSParam((uint8_t *)msPtr + (iy * w + ix) * abs(msTypeSize), msTypeSize, coef, reciprocal);
			int s3Offs = inverseY ? (h - 1 - iy) * w + ix : iy * w + ix;
			switch (s3TypeSize)
			{
			case -1: ((int8_t *)s3Ptr)[s3Offs] = (int8_t)res; break;
			case -2: ((int16_t *)s3Ptr)[s3Offs] = (int16_t)res; break;
			case -4: ((int32_t *)s3Ptr)[s3Offs] = (int32_t)res; break;
			case 1: ((uint8_t *)s3Ptr)[s3Offs] = (uint8_t)res; break;
			case 2: ((uint16_t *)s3Ptr)[s3Offs] = (uint16_t)res; break;
			case 4: ((uint32_t *)s3Ptr)[s3Offs] = (uint32_t)res; break;
			}
		}
	}
}


///////////////////////////////////////////////////////////

int getAfrTableSortOrder(const std::vector<CSVRecord> & rec)
{
	bool asc = true, desc = true;
	for (size_t i = 1; i < rec.size(); i++)
	{
		if (rec[i - 1].fields[1] < rec[i].fields[1])
			desc = false;
		if (rec[i - 1].fields[1] > rec[i].fields[1])
			asc = false;
	}
	return asc ? 1 : (desc ? -1 : 0);
}

double interpolate(double x, double x0, double x1, double y0, double y1)
{
	return y0 + ((x - x0) / (x1 - x0)) * (y1 - y0);
}

double linear(double fx, double v00, double v01)
{
	double fx1 = 1.0 - fx;
	return (v00 * fx1) + (v01 * fx);
}

double bilinear(double fx, double fy, double v00, double v01, double v10, double v11)
{
	double fx1 = 1.0 - fx;
	double fy1 = 1.0 - fy;
	return (v00 * fx1 * fy1) + (v01 * fx * fy1) + (v10 * fx1 * fy) + (v11 * fx * fy);
}

// interpolate (ascending table order)
double getAFR(double v)
{
	std::vector<CSVRecord> &rec = afrRecords[lambdaType];
	if (rec.size() > 0)
	{
		double prev = 0.0, afr = rec[0].fields[0];
		if (v <= rec[0].fields[1])
			return rec[0].fields[0];
		if (v >= rec[rec.size() - 1].fields[1])
			return rec[rec.size() - 1].fields[0];
		for (size_t i = 0; i < rec.size() - 1; i++)
		{
			if (v < rec[i + 1].fields[1])
			{
				return interpolate(v, rec[i].fields[1], rec[i + 1].fields[1], rec[i].fields[0], rec[i + 1].fields[0]);
			}
		}
	}
	return 0.0;
}

double getRPMIndex()
{
	if (d.sens.frequen <= fw.exdata.rpm_grid_points[0])
		return 0.0;
	if (d.sens.frequen >= fw.exdata.rpm_grid_points[RPM_GRID_SIZE - 1])
		return (double)(RPM_GRID_SIZE - 1);
	for (int i = 0; i < RPM_GRID_SIZE; i++)
	{
		if (d.sens.frequen < fw.exdata.rpm_grid_points[i + 1])
			return (double)i + (double)(d.sens.frequen - fw.exdata.rpm_grid_points[i]) / (double)(fw.exdata.rpm_grid_points[i + 1] - fw.exdata.rpm_grid_points[i]);
	}
	return 0.0;
}

double getLoadIndex()
{
	if (d.param.load_src_cfg == 0)	// MAP
	{
		// d.airflow is integer, and we need a floating point value...
		if (d.sens.map <= d.param.map_lower_pressure)
			return (double)(INJ_VE_POINTS_L - 1);
		if (d.sens.map >= d.param.map_upper_pressure)
			return 0.0;
		return (double)(INJ_VE_POINTS_L - 1) * (double)(d.param.map_upper_pressure - d.sens.map) / (double)(d.param.map_upper_pressure - d.param.map_lower_pressure);
	}
	else if (d.param.load_src_cfg == 1)	// TPS
	{
		return (double)(INJ_VE_POINTS_L - 1) * (1.0 - (double)d.sens.tps / 200.0);
	}
	return 0.0;
}

double getTempIndex()
{
	double low = TEMPERATURE_MAGNITUDE(-30);
	double high = TEMPERATURE_MAGNITUDE(130);
	if (d.sens.temperat <= low)
		return 0.0;
	if (d.sens.temperat >= high)
		return (double)(F_TMP_POINTS - 1);
	return (double)(F_TMP_POINTS - 1) * ((double)d.sens.temperat - low) / (high - low);
}

double getAfrTarget()
{
	double irpm, iload;
	double rpm = getRPMIndex();
	double load = getLoadIndex();
	int x = (int)rpm;
	int y = (int)load;
	double v = bilinear(modf(rpm, &irpm), modf(load, &iload),
		d.tables_ram.inj_afr[y][x], d.tables_ram.inj_afr[y][x + 1],
		d.tables_ram.inj_afr[y + 1][x], d.tables_ram.inj_afr[y + 1][x + 1]);
	return 2048.0 / v;
}

double getVe()
{
	double irpm, iload;
	double rpm = getRPMIndex();
	double load = getLoadIndex();
	int x = (int)rpm;
	int y = (int)load;
	double v = bilinear(modf(rpm, &irpm), modf(load, &iload),
		d.tables_ram.inj_ve[y][x], d.tables_ram.inj_ve[y][x + 1],
		d.tables_ram.inj_ve[y + 1][x], d.tables_ram.inj_ve[y + 1][x + 1]);
	return v / 128.0;
}

double getWue()
{
	double itemp;
	double temp = getTempIndex();
	int x = (int)temp;
	double v = linear(modf(temp, &itemp), d.tables_ram.inj_warmup[x], d.tables_ram.inj_warmup[x + 1]);
	return v / 128.0;
}

double getAse()
{
	double itemp;
	double temp = getTempIndex();
	int x = (int)temp;
	double v = linear(modf(temp, &itemp), d.tables_ram.inj_aftstr[x], d.tables_ram.inj_aftstr[x + 1]);
	return v / 128.0;
}

double getStoich()
{
	return d.sens.gas ? p.stoich[1] : p.stoich[0];	// \TODO: add stoich param to SECU...
}

///////////////////////////////////////////////////////////

void sendToBoard()
{
	writePort(BoardIn, uart.send_buf, uart.send_size);
}

void s3ChangeMode(int id)
{
	PacketParams params;
	params.modeId = id;
	send_s3_master_packet(uart, &d, fw, CHANGEMODE, params);
	sendToBoard();
}

void s3BurnEEPROM()
{
	log("Burning to EEPROM...\n");

	/// \TODO: add OPCODE_EEPROM_PARAM_SAVE...

	PacketParams params;
	params.opCode = OPCODE_SAVE_TABLSET;
	params.opData = TABLES_NUMBER_PGM;
	send_s3_master_packet(uart, &d, fw, OP_COMP_NC, params);
	sendToBoard();

	lastSavedTime = getTimeInSeconds();
}

void s3SaveTable(int tableIdx, int addr, int size)
{
	PacketParams params;
	params.mapIndex = tableIdx;
	params.mapAddress = addr;
	params.mapSize = size;
	send_s3_master_packet(uart, &d, fw, EDITAB_PAR, params);
	sendToBoard();
}

void s3GetFWInfo()
{
	log("Getting FW Info...\n");
	PacketParams params;
	params.opCode = OPCODE_READ_FW_SIG_INFO;	// request FWINFO_DAT
	send_s3_master_packet(uart, &d, fw, OP_COMP_NC, params);
}

//////////////////////////////////////////////////////////////////

void updateInp()
{
	log("* Updating parameters...\n");

	int i;
	setMSParam(ms.inpram.ECUType, 1);  // 1=MS-II
	setMSParam(ms.inpram.CWOption, 1); // 1=Prime, ASE, WUE & Baro Tables
	setMSParam(ms.inpram.no_cyl, d.param.ckps_engine_cyl);
	setMSParam(ms.inpram.CID, d.param.inj_cyl_disp * d.param.ckps_engine_cyl, 0.003724585571289);  // litres*16384 -> cubic inches
	setMSParam(ms.in2ram.fRate, d.param.inj_flow_rate, 0.1875);    // cc/min*64 -> g/s
#if 0
	setMSParam(ms.inpram.baro0, 0);    // kPa
	setMSParam(ms.inpram.baromax, 1000.0); // kPa
#endif
	setMSParam(ms.inpram.clt0, round_int(((-30) * 1.8 + 32.0) * 10.0));		// -30 celsius degrees -> fahrenheit
	setMSParam(ms.inpram.primePulseCold, d.param.inj_prime_cold, 1.0 / 31.25);
	setMSParam(ms.inpram.primePulseHot, d.param.inj_prime_hot, 1.0 / 31.25);

	lambdaType = ((double)d.param.inj_lambda_swt_point / 400) < 1.0 ? Narrow : Wide;
	wideMode = lambdaType == Wide || p.emulateWide;
	setMSParam(ms.inpram.egoType, wideMode ? 3 : 1);
	setMSParam(ms.inpram.AFRMult, wideMode ? 2 : 1);	// "Separate VE & AFR table w/ WB or NB EGO"

	double stoich = getStoich();

	if (p.setAfrTarget)
	{
		if (wideMode)
			setMSParam(ms.inpram.AFRTarget, stoich, 10.0);
		else
			setMSParam(ms.inpram.AFRTarget, d.param.inj_lambda_swt_point, 100.0 / 400.0);
	}

	if (wideMode)
		setMSParam(ms.inpram.AFRStoich, stoich, 10.0);
	else
		setMSParam(ms.inpram.AFRStoich, d.param.inj_lambda_swt_point, 100.0 / 400.0);

	setMSParam(ms.inpram.egoCount, d.param.inj_lambda_str_per_stp);
	setMSParam(ms.inpram.egoDelta, Min(d.param.inj_lambda_step_size_p, d.param.inj_lambda_step_size_m), 100.0 / 512.0);
	setMSParam(ms.inpram.egoLimit, Min(d.param.inj_lambda_corr_limit_p, d.param.inj_lambda_corr_limit_m), 100.0 / 512.0);
	setMSParam(ms.inpram.egoTemp, round_int(((double)d.param.inj_lambda_temp_thrd / 4.0 * 1.8 + 32.0) * 10.0));
	setMSParam(ms.inpram.egoRPM, d.param.inj_lambda_rpm_thrd);

	switch (d.param.inj_config >> 4)
	{
	case INJCFG_THROTTLEBODY:
		setMSParam(ms.inpram.NoInj, 1);
		setMSParam(ms.inpram.InjType, 1);
		break;
	case INJCFG_2BANK_ALTERN:
		setMSParam(ms.inpram.NoInj, d.param.ckps_engine_cyl / 2);
		break;
	default:
		setMSParam(ms.inpram.NoInj, d.param.ckps_engine_cyl);
	}

	setMSParam(ms.inpram.divider, 1);

	// convert Celsius -30..120 to Fahrenheit
	for (i = 0; i < NO_TEMPS; i++)
	{
		setMSParam(ms.inpram.tempTable[i], round_int((((i * 10.0) + (-30.0)) * 1.8 + 32.0) * 10.0));
		// set prime pulse table from linear interpolation
		setMSParam(ms.in2ram.primePWTable[i], Max(round_int(((double)d.param.inj_prime_cold + (d.param.inj_prime_hot - d.param.inj_prime_cold) * i / ((70.0 - (-30.0)) / 10.0)) / 31.25), 0));
	}

	assert(NO_FMAPS == INJ_VE_POINTS_L && NO_SMAPS == INJ_VE_POINTS_L);
	for (i = 0; i < NO_FMAPS; i++)
	{
		int m = round_int((d.param.map_lower_pressure + (double)i * (d.param.map_upper_pressure - d.param.map_lower_pressure) / (INJ_VE_POINTS_L - 1)) / 64.0 * 10.0);
		setMSParam(ms.inpram.fmap_table[i], m);
		setMSParam(ms.inpram.smap_table[i], m);
	}

	assert(NO_FRPMS == RPM_GRID_SIZE && NO_SRPMS == RPM_GRID_SIZE);
	setMSTable(ms.inpram.frpm_table, 2, fw.exdata.rpm_grid_points, -2, NO_FRPMS, 1, 1.0);
	setMSTable(ms.inpram.srpm_table, 2, fw.exdata.rpm_grid_points, -2, NO_SRPMS, 1, 1.0);

	// for RT-tables
	assert(NO_FMAPS == INJ_VE_POINTS_L && NO_FRPMS == INJ_VE_POINTS_F);
	assert(NO_SMAPS == F_WRK_POINTS_L && NO_SRPMS == F_WRK_POINTS_F);
	assert(NO_TEMPS == INJ_WARMUP_LOOKUP_TABLE_SIZE);
	assert(16 == INJ_AFTSTR_LOOKUP_TABLE_SIZE);
	assert(16 == INJ_CRANKING_LOOKUP_TABLE_SIZE);
	assert(NO_TEMPS == F_TMP_POINTS);
}

void setReadOnly()
{
	log("* Using READ-ONLY mode!!!\n");
	readOnlyMode = true;
}

void updateRTTables()
{
	log("* Updating MS tables...\n");

	assert(curTblIdx >= 0 && curTblIdx <= TABLES_NUMBER_PGM);

	if (curTblIdx < TABLES_NUMBER_PGM)
	{
		log("* WARNING! Please switch to the active RT-table for full-functional mode!\n");
		setReadOnly();
	}
	else
	{
		log("* Active RT-table detected!\n  Using full-functional mode!\n");
		readOnlyMode = false;
	}

	const TableRT *tablesRT = getTablesRT();
	for (int i = 0; tablesRT[i].msTableIdx >= 0; i++)
	{
		setMSTable(msPtr + tablesRT[i].msOffs, tablesRT[i].msTypeSize, dPtr + tablesRT[i].s3Offs, tablesRT[i].s3TypeSize,
                   tablesRT[i].width, tablesRT[i].height, tablesRT[i].coef, tablesRT[i].reciprocal, tablesRT[i].inverseY);
	}
}

void burnTable(int tbl, int off, int siz)
{
	const TableRT *tablesRT = getTablesRT();

	for (int i = 0; tablesRT[i].msTableIdx >= 0; i++)
	{
		if (tbl == tablesRT[i].msTableIdx)
		{
			int msTypeSize = abs(tablesRT[i].msTypeSize);
			int tblStart = (int)(&msPtr[tablesRT[i].msOffs] - tables[tbl]);
			int tblSize = tablesRT[i].width * tablesRT[i].height * msTypeSize;
			// if we're inside one of RT tables...
			if (off >= tblStart && off + siz <= tblStart + tblSize)
			{
				log("  * Table %s -> SECU-3\n", tablesRT[i].name);
				getMSTable(msPtr + tablesRT[i].msOffs, tablesRT[i].msTypeSize, dPtr + tablesRT[i].s3Offs, tablesRT[i].s3TypeSize,
                           tablesRT[i].width, tablesRT[i].height, tablesRT[i].coef, tablesRT[i].reciprocal, tablesRT[i].inverseY);

				int relOffs = (off - tblStart) / abs(tablesRT[i].msTypeSize);
				int x = relOffs % tablesRT[i].width;
				int y = relOffs / tablesRT[i].width;
				int n = (siz + msTypeSize - 1) / msTypeSize;    // round to typeSize
				while (n > 0)
				{
					int nn = Min(n, tablesRT[i].width - x);
					int addr = (tablesRT[i].inverseY ? tablesRT[i].height - 1 - y : y) * tablesRT[i].width + x;

					s3SaveTable(tablesRT[i].s3tableIdx, addr, nn);
					x = 0;
					y++;
					n -= nn;
					delay(n > 0 ? 5 : 2);  // give it some time...
				}
				needsSaving = true;
				break;
			}
		}
	}

}

void overrideEgo(double v)
{
	overrideEgoValue = wideMode ? v * 5.0 : v;
	d.sens.add_i1 = (uint16_t)overrideEgoValue;
}

void overrideAfr(double v)
{
	overrideAfrValue = 14.7 + (v / 400.0 - 0.5) * 5.7;
	setMSParam(&ms.outpc.afrtgt1, 1, overrideAfrValue, 10.0, false);
}

void updateSensorData()
{
	const SensorParam *sensorParams = getSensorParams();

	for (int i = 0; sensorParams[i].name != nullptr; i++)
	{
		if (sensorParams[i].ms.offs == -1)  // not used for MS update
			continue;
		int val;
		switch (sensorParams[i].s3.size)
		{
			// signed
		case -1: val = *((int8_t *)&dPtr[sensorParams[i].s3.offs]); break;
		case -2: val = *((int16_t *)&dPtr[sensorParams[i].s3.offs]); break;
		case -4: val = *((int32_t *)&dPtr[sensorParams[i].s3.offs]); break;
			// unsigned
		case 1: val = *((uint8_t *)&dPtr[sensorParams[i].s3.offs]); break;
		case 2: val = *((uint16_t *)&dPtr[sensorParams[i].s3.offs]); break;
		case 4: val = *((uint32_t *)&dPtr[sensorParams[i].s3.offs]); break;
		}

		double f = (double)val / sensorParams[i].s3.coef + sensorParams[i].s3.add;
		double msf = f * sensorParams[i].ms.coef + sensorParams[i].ms.add;

		setMSParam(msPtr + sensorParams[i].ms.offs, sensorParams[i].ms.size, msf, 1.0, false);
	}

	// just copy big-endian as is
	ms.outpc.kpaix = ms.outpc.map;

	if (startTime < 0)
		startTime = getTimeInSeconds();
	setMSParam(ms.outpc.seconds, (int)(getTimeInSeconds() - startTime));

	if (overrideEgoValue >= 0.0)
		d.sens.add_i1 = (uint16_t)overrideEgoValue;

	double afr = getAFR((double)d.sens.add_i1 / 400.0);

	if (p.setAfrTarget)
	{
		double ve = getVe();
		setMSParam(&ms.outpc.vecurr1, -2, ve, 100.0, false);
		double afrTarget = getAfrTarget();
		if (overrideAfrValue >= 0.0)
			afrTarget = overrideAfrValue;

		//double afrtgt1 = getStoich() * getStoich() / afrTarget;
		double afrtgt1 = afrTarget;
		setMSParam(&ms.outpc.afrtgt1, 1, afrtgt1, 10.0, false);
	}

	//double ase = getAse();
	double wue = getWue();
	int isWue = (wue != 1.0) ? 1 : 0;
	int isAse = 0;// TODO:... (ase != 1.0) ? 1 : 0;
	int isTpsAcc = 0;// TODO:... (d.sens.tpsdot > 0) ? 1 : 0;
	int isTpsDec = 0;// TODO:...(d.sens.tpsdot < 0) ? 1 : 0;
	setMSParam(&ms.outpc.warmcor, -2, wue, 100.0, false);
	setMSParam(&ms.outpc.iacstep, -2, d.choke_pos, 1.0, false);

	ms.outpc.engine = ((1/*ign*/) << 0) | ((1 - d.st_block) << 1) | (isAse << 2) | (isWue << 3) | (isTpsAcc << 4) | (isTpsDec << 4);

	if (lambdaType == Wide || p.emulateWide)
	{
		setMSParam(&ms.outpc.afr1, -2, afr, 10.0, false);
		setMSParam(&ms.outpc.egoV1, -2, /* afr? */d.sens.add_i1, 100.0 / 400.0, false);
	}
	else
	{
		setMSParam(&ms.outpc.afr1, -2, afr, 10.0, false);
		setMSParam(&ms.outpc.egoV1, -2, d.sens.add_i1, 100.0 / 400.0, false);
	}

	updateGuiStatus(getAFR((double)d.sens.add_i1 / 400.0), (double)getMSParam(&ms.outpc.afrtgt1, 1, 1.0, false) / 10.0);

	if (state == TablesReceived)
	{
		curTblIdx = getTableIndex(d, curTblIdx);
		updateRTTables();
		updateInp();
		log("Starting communication with MS software...\n");
		state = Normal;
	}

}

void setStateEnabled(S3CommunicationState state, bool en)
{
	for (int i = 0; initStateMachine[i].mode > 0; i++)
	{
		if (initStateMachine[i].state == state)
		{
			initStateMachine[i].enabled = en;
			break;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////

bool processMSCommand(uint8_t cmd)
{
	uint8_t buf[4096];
	int num;

	switch (cmd)
	{
	case 'Q':       // revision
		DEBUG_MS("MS->%c\n", cmd);
		writePort(SoftOut, (uint8_t *)RevNum, 20);
		DEBUG_MS("  -> %s\n", RevNum);
		break;
	case 'S':       // signature
		DEBUG_MS("MS->%c\n", cmd);
		writePort(SoftOut, (uint8_t *)Signature, 32);
		DEBUG_MS("  -> %s\n", Signature);
		log("* Send signature...\n");
		break;
	case 'c':       // check communication
		DEBUG_MS("MS->%c\n", cmd);
		writePort(SoftOut, (uint8_t *)&ms.outpc.seconds, 2);
		DEBUG_MS("  -> %08x\n", ms.outpc.seconds);
		log("* Check communication...\n");
		break;
	case 'F':		// reset Tx buffer?
		DEBUG_MS("MS->%c\n", cmd);
		break;
	case 'a':
	case 'A':
	{
		readPort(SoftOut, buf, 2, &num);
		int tbl = buf[1];
		static int cnt = 0;
		DEBUG_MS("[%d] MS->%c CAN=%d TBL=%d\n", cnt++, cmd, buf[0], tbl);
		if (tables[tbl] != nullptr)
		{
			writePort(SoftOut, (uint8_t *)tables[tbl], sizeof(variables));
		}
		break;
	}
	case 'r':
	{
		readPort(SoftOut, buf, 6, &num);
		int tbl = buf[1];
		int off = num > 3 ? (buf[2] << 8) | buf[3] : 0;
		int siz = num > 5 ? (buf[4] << 8) | buf[5] : table_size[tbl] - off;
		DEBUG_MS("MS->%c CAN=%d TBL=%d OFF=%d, SIZ=%d\n", cmd, buf[0], tbl, off, siz);
		if (tables[tbl] != nullptr)
		{
			assert(off >= 0 && off + siz <= table_size[tbl]);
			{
				writePort(SoftOut, tables[tbl] + off, siz);
			}
		}

		log("* Read table #%d offset=%d size=%d!\n", tbl, off, siz);

		break;
	}
	case 'w':
	{
		readPort(SoftOut, buf, 6, &num);
		int tbl = buf[1];
		int off = num > 3 ? (buf[2] << 8) | buf[3] : 0;
		int siz = num > 5 ? (buf[4] << 8) | buf[5] : table_size[tbl] - off;
		assert(siz < sizeof(buf));
		readPort(SoftOut, buf, siz, &num);
		DEBUG_MS("MS->%c CAN=%d TBL=%d OFF=%d, SIZ=%d numRead=%d\n", cmd, buf[0], tbl, off, siz, num);
#if 0
		for (int i = 0; i < num; i++)
		{
			printf(" %d", buf[i]);
		}
		if (num > 0)
			printf("\n");
#endif
		assert(off >= 0 && off + siz <= table_size[tbl]);
		memcpy(tables[tbl] + off, buf, siz);

		log("* %s data #%d offset=%d size=%d!\n", (readOnlyMode ? "Update" : "Burn"), tbl, off, siz);

		if (!readOnlyMode)
		{
			burnTable(tbl, off, siz);
		}

		break;
	}
	case 'b':	// save params
	{
		readPort(SoftOut, buf, 2, &num);
		int tbl = buf[1];
		DEBUG_MS("MS->%c CAN=%d TBL=%d\n", cmd, buf[0], tbl);
		s3BurnEEPROM();
		break;
	}
	case 't':	// burn calibration tables
	{
		readPort(SoftOut, buf, 1, &num);
		int tbl = buf[0];
		DEBUG_MS("MS->%c TBL=%d\n", cmd, tbl);
		readPort(SoftOut, buf, 1024, &num);
		log("* Calibration tables are currently not supported, sorry!");

#ifdef DUMP_CALIBRATION_TABLES
		std::string fName = "dump_table" + std::to_string(tbl) + ".dat";
		log(" Dumping table to %s", fName.c_str());
		FILE *fp = fopen(fName.c_str(), "wb");
		fwrite(buf, num, 1, fp);
		fclose(fp);
#endif
		log("\n");

		// reset timeout counter?
		lastReceivedPackedTime = getTimeInSeconds();
		break;
	}
	default:
		DEBUG_MS("MS->'%c' (%d) ???\n", cmd > 32 ? cmd : ' ', cmd);
		break;
	}
	return true;
}

bool processS3Command(uint8_t cmd)
{
	// if there's no magic header - skip damaged data
	if (cmd != '@')
		return false;

	const int maxBufLen = UART_RECV_BUFF_SIZE;
	uint8_t *buf = uart.recv_buf;
	int len;
	for (len = 0; len < maxBufLen; len++)
	{
		int num;
		readPort(BoardIn, &buf[len], 1, &num);
		if (num < 1)
			return false;
		if (buf[len] == '\r')   // EOL
		{
			len++;
			break;
		}
	}
	if (len >= maxBufLen)   // packet is too big - skip!
		return false;
	uart.recv_size = len;
	int descr = receive_s3_packet(uart, &d, fw);

	if (state == Initial)
	{
		log("Data received and SECU-3 board detected!\n");

		log("Getting parameters...\n");
		state = ParamFWInfoSent;
	}

	for (int i = 0; initStateMachine[i].mode > 0; i++)
	{
		if (initStateMachine[i].state == state)
		{
			if (descr == initStateMachine[i].mode || !initStateMachine[i].enabled)
			{
				if (descr == initStateMachine[i].mode && initStateMachine[i].name[0] != '\0')
					log("* %s params received!\n", initStateMachine[i].name);
				if (initStateMachine[i].next > 0)
				{
					state = initStateMachine[i].next;
					if (state == TableQuerySent)
					{
						log("Getting real-time tables...\n");
					}
					// start over
					i = -1;
					continue;
				}
				break;
			}
			s3ChangeMode(initStateMachine[i].mode);
			break;
		}
	}

	switch (descr)
	{
	case SENSOR_DAT:
		updateSensorData();
		break;
	case FWINFO_DAT:
	{
		// check RT-tables support
		if (((fw.cddata.config >> COPT_REALTIME_TABLES) & 1) == 0)
		{
			log("* WARNING! Real-time table support not found in FW options!\n");
			setReadOnly();
		}
		// detect FW injection or GD support
		bool newInjMode = ((fw.cddata.config >> COPT_FUEL_INJECT) & 1) != 0;
		bool newGdMode = ((fw.cddata.config >> COPT_GD_CONTROL) & 1) != 0;
		if (newInjMode != injMode || newGdMode != gdMode || (!newInjMode && !newGdMode))
		{
			injMode = newInjMode;
			gdMode = newGdMode;
			if (injMode)
				log("  Injection Mode Detected!\n");
			else if (gdMode)
				log("  GasDose Mode Detected!\n");
			else
				log("* WARNING! NO INJECTION OR GASDOSE SUPPORT DETECTED!\n");
		}
		// don't get unsupported parameters
		setStateEnabled(ParamInjSent, injMode);
		setStateEnabled(ParamGDSent, gdMode);
		break;
	}
	case LAMBDA_PAR:
	{
		int newLambdaType = ((double)d.param.inj_lambda_swt_point / 400) < 1.0 ? Narrow : Wide;
		if (newLambdaType != lambdaType)
		{
			lambdaType = newLambdaType;
			log("  Using: %s EGO\n", lambdaType == Wide ? "WideBand" : (p.emulateWide ? "NarrowEmulWide" : "NarrowBand"));
		}
		break;
	}
	case EDITAB_PAR:
		if (state == TableQuerySent)
			state = TablesReceiving;

		if (state == TablesReceiving && get_s3_tblIdx(uart) == ETMT_STRT_MAP)   // first table?
			state = TablesReceivedFirst;
		else if (state == TablesReceivedFirst && get_s3_tblIdx(uart) == ETMT_IT_MAP)    // last table?
		{
			state = TablesReceived;
			log("* Real-time tables received!\n");
			s3ChangeMode(SENSOR_DAT);
		}
		break;
	}
	return true;
}

bool resetState()
{
	log("Opening BOARD serial port %s @ %d...\n", p.portIn[Ms].c_str(), p.baudIn[Ms]);
	if (!initPort(BoardIn, p.portIn[Ms], p.baudIn[Ms]))
	{
		log("ERROR!\n");
		return false;
	}

	log("Opening SOFT serial port %s @ %d...\n", p.portOut[Ms].c_str(), p.baudOut[Ms]);
	if (!initPort(SoftOut, p.portOut[Ms], p.baudOut[Ms]))
	{
		log("ERROR!\n");
		return false;
	}

	state = Initial;
	memset(&ms, 0, sizeof(MsParams));
	memset(&d, 0, sizeof(struct ecudata_t));
	memset(&fw, 0, sizeof(struct fw_data_t));

	curTblIdx = -1;
	wideMode = true;
	injMode = false;
	gdMode = false;

	init_s3_uart(uart, false);
	return true;
}

int emulMS(const s3emul_params & params)
{
	log("Starting SECU-MS Bridge!\n");

	p = params;

	if (!resetState())
		return -1;

	log("Emulating MegaSquirt board...\n");

	for (int i = 0; i < 2; i++)
	{
		if (p.afrFileName[i][0] != '\0')
		{
			log("Reading lambda AFR table file %s...\n", p.afrFileName[i].c_str());
			afrRecords[i].clear();
			if (!readCSVFile(p.afrFileName[i], afrRecords[i], nullptr))
			{
				log("ERROR reading file!\n");
				return false;
			}

			if (afrRecords[i].size() < 2)
			{
				log("Minimum two AFR values required!\n");
				return false;
			}

			int afrSortOrder = getAfrTableSortOrder(afrRecords[i]);
			if (afrSortOrder == 0)
			{
				log("Wrong or mixed AFR table sort order!\n");
				return false;
			}
			// only ascending order is supported
			if (afrSortOrder < 0)
				std::reverse(afrRecords[i].begin(), afrRecords[i].end());
		}
	}

	log("Listening to SECU-3 board...\n");

	startTime = getTimeInSeconds();
	lastSavedTime = startTime;
	lastReceivedPackedTime = startTime;

	for (;;)
	{
		uint8_t cmd;
		int num;

		if (getExiting())
			break;

		if (!peekPortByte(BoardIn, &cmd, &num))
		{
			log("Connection with board COM-port lost!\n");
			break;
		}
		if (num > 0)
		{
			processS3Command(cmd);
			lastReceivedPackedTime = getTimeInSeconds();
		}

		if (state == Normal)
		{
			if (!peekPortByte(SoftOut, &cmd, &num))
			{
				log("Connection with software COM-port lost!\n");
				break;
			}
			if (num > 0)
			{
				processMSCommand(cmd);
			}

			double curTime = getTimeInSeconds();
			if (needsSaving && curTime - lastSavedTime >= p.saveTimePeriod) // save every N seconds - if needed
			{
				s3BurnEEPROM();
				needsSaving = false;
			}
		}
		else
		{
			delay(1);
		}

		// if no more packets coming from the board...
		if (state != Initial && getTimeInSeconds() - lastReceivedPackedTime > p.s3ConnectionTimeout)
		{
			log("SECU-3 Connection TIMEOUT! Restarting...\n");

			startTime = -1;

			deInitPort(BoardIn);
			deInitPort(SoftOut);

			if (!resetState())
				break;

			log("Listening to SECU-3 board...\n");
		}
	}

	deInitPort(BoardIn);
	deInitPort(SoftOut);

	return 0;
}

