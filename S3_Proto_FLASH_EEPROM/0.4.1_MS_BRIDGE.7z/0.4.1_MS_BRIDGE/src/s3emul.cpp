#include "ms_defs.h"
#include "ms_defs.h"
/* s3emul - "secu3 emulator"
   Copyright (C) 2016 andreika. Ukraine, Kiev

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org/forum/ucp.php?i=pm&mode=compose&u=740

*/

#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <array>
#include <time.h>

#include "s3.h"

#include "s3emul.h"
#include "port.h"



char cfgName[4096];
static char *paramsFile = "params.cfg";
static Mode mode;

static bool exiting = false;

static SensorParam sensorParams[] =
{
    { "frequen",        1,  { offsetof(D, sens.frequen), 2, 1.0 },            { offsetof(MsParams, outpc.rpm), 2, 1.0 } },
    { "curr_angle",     2,  { offsetof(D, corr.curr_angle), -2, 32.0 },       { offsetof(MsParams, outpc.adv_deg), -2, 10.0 } },
    { "map",            3,  { offsetof(D, sens.map), 2, 64.0 },               { offsetof(MsParams, outpc.map), -2, 10.0 } },
    { "voltage",        4,  { offsetof(D, sens.voltage), 2, 400.0 },          { offsetof(MsParams, outpc.batt), -2, 10.0 } },
    { "temperat",       5,  { offsetof(D, sens.temperat), -2, 4.0 },          { offsetof(MsParams, outpc.clt), -2, 10.0 * 1.8, 10.0 * 32.0 } },  // Celsius->Fahrenheit
    { "knock_k",        6,  { offsetof(D, sens.knock_k), 2, 1.0 },            { -1, 0, 1.0 } },
    { "knock_retard",   7,  { offsetof(D, corr.knock_retard), -2, 1.0 },      { offsetof(MsParams, outpc.knockRetard), 1, 10.0 } },
    { "airflow",        8,  { offsetof(D, airflow), 1, 1.0 },                 { -1, 0, 1.0 } },
    { "carb",           9,  { offsetof(D, sens.carb), 1, 1.0 },               { -1, 0, 1.0 } },
    { "gas",            10, { offsetof(D, sens.gas), 1, 1.0 },                { -1, 0, 1.0 } },
    { "ie_valve",       11, { offsetof(D, ie_valve), 1, 1.0 },                { -1, 0, 1.0 } },
    { "fe_valve",       12, { offsetof(D, fe_valve), 1, 1.0 },                { -1, 0, 1.0 } },
    { "cool_fan",       13, { offsetof(D, cool_fan), 1, 1.0 },                { -1, 0, 1.0 } },
    { "st_block",       14, { offsetof(D, st_block), 1, 1.0 },                { -1, 0, 1.0 } },
    { "acceleration",   15, { offsetof(D, acceleration), 1, 1.0 },            { -1, 0, 1.0 } },
    { "tps",            16, { offsetof(D, sens.tps), 1, 2.0 },                { offsetof(MsParams, outpc.tps), -2, 10.0 } },
    { "add_i1",         17, { offsetof(D, sens.add_i1), 2, 400.0 },           { -1, 0, 0.0 } },	// see updateSensorData()
    { "add_i2",         18, { offsetof(D, sens.add_i2), 2, 400.0 },           { -1, 0, 1.0 } },
    { "choke_pos",      19, { offsetof(D, choke_pos), 1, 2.0 },               { -1, 0, 1.0 } },
    { "speed",          20, { offsetof(D, sens.speed), 2, 1.0 },              { -1, 0, 1.0 } },
    { "distance",       21, { offsetof(D, sens.distance), 4, 1.0 },           { -1, 0, 1.0 } },
    { "gasdose_pos",    22, { offsetof(D, gasdose_pos), 1, 1.0 },             { -1, 0, 1.0 } },
    { "air_temp",       23, { offsetof(D, sens.air_temp), -2, 4.0 },          { offsetof(MsParams, outpc.mat), -2, 10.0 * 1.8, 10.0 * 32.0 } },  // Celsius->Fahrenheit
    { "lambda",         31, { offsetof(D, corr.lambda), -2, 512.0 },          { offsetof(MsParams, outpc.egocor1), -2, 1.0 } },
    { "inj_pw",         32, { offsetof(D, inj_pw), 2, 320.0 },                { offsetof(MsParams, outpc.pw1), 2, 1000.0 } },    // in usec
    { "tpsdot",         33, { offsetof(D, sens.tpsdot), -2, 1.0 },            { offsetof(MsParams, outpc.tpsdot), -2, 10.0 } },
    { "ecuerrors",      34, { offsetof(D, ecuerrors_for_transfer), 2, 1.0 },  { -1, 0, 1.0 } },
    { "ce_state",       35, { offsetof(D, ce_state), 1, 1.0 },                { -1, 0, 1.0 } },
    { nullptr,          -1, { -1, 0, 1.0 },                                   { -1, 0, 1.0 } },
};

static TableRT tablesRT[] =
{
    { "AFR",        4, ETMT_AFR_MAP,    offsetof(MsParams, inpram.afr_table1),     offsetof(D, tables_ram.inj_afr),       1, 1, NO_FRPMS, NO_FMAPS, 2048.0 * 10.0, true, true },
    { "VE",         5, ETMT_VE_MAP,     offsetof(MsParams, in2ram.ve_table1),      offsetof(D, tables_ram.inj_ve),        1, 1, NO_FRPMS, NO_FMAPS, 100.0 / 128.0, true },
    { "Adv.Angle",  5, ETMT_WORK_MAP,   offsetof(MsParams, in2ram.adv_table),      offsetof(D, tables_ram.f_wrk),        -2, -1, NO_SRPMS, NO_SMAPS, 5.0, true },
    { "Warmup",     4, ETMT_WRMP_MAP,   offsetof(MsParams, inpram.wueBins),        offsetof(D, tables_ram.inj_warmup),    1, 1, NO_TEMPS, 1, 100.0 / 128.0 },
	{ "AfterStart", 5, ETMT_AFTSTR_MAP, offsetof(MsParams, in2ram.asePctTable),    offsetof(D, tables_ram.inj_aftstr),   -2, 1, 16, 1, 100.0 / 128.0 },
    { "Cranking",   5, ETMT_CRNK_MAP,   offsetof(MsParams, in2ram.crankPWTable),   offsetof(D, tables_ram.inj_cranking), -2, 2, 16, 1, 1.0 / 31.25 },
    { "ColdAdv.",   4, ETMT_TEMP_MAP,   offsetof(MsParams, inpram.cold_adv_table), offsetof(D, tables_ram.f_tmp),        -2, -1, NO_TEMPS, 1, 5.0 },
    { nullptr,      -1, -1,             -1,                                        -1,                                    0, 0, 0, 0, 0.0 }
};

//////////////////////////////////////////////////////////////////

const SensorParam *getSensorParams()
{
	return sensorParams;
}

const TableRT *getTablesRT()
{
	return tablesRT;
}

void setExiting(bool e)
{
	exiting = e;
}

bool getExiting()
{
	return exiting;
}

//////////////////////////////////////////////////////////////////

int getTableIndex(const struct ecudata_t & d, int curTblIdx)
{
    int tblIdx;
    uint8_t mapsel0 = 0; // = IOCFG_CHECK(IOP_MAPSEL0) ? IOCFG_GET(IOP_MAPSEL0) : 0;

    if (d.sens.gas)
        tblIdx = mapsel0 ? 1 : d.param.fn_gas;          //on gas
    else
        tblIdx = mapsel0 ? 0 : d.param.fn_gasoline;     //on petrol

	assert(tblIdx >= 0 && tblIdx < TABLES_NUMBER);
	return tblIdx;
}

//////////////////////////////////////////////////////////////////////////////////

s3emul_params readParams(const std::string & fname)
{
	s3emul_params p;
	static const char *smode[] = { "MS", "SECU", nullptr };
	static const Mode imode[] = { Ms, Secu }; // 	Ms = 0, Secu, =1, Test =2

	log("Reading params from %s...\n", fname.c_str());
	std::string cfgName = openIni(fname);

	for (int mode = 0; smode[mode] != nullptr; mode++)
	{
		p.portIn[imode[mode]] = getIniString(smode[mode], "PortIn", "COM1", cfgName);
		p.portOut[imode[mode]] = getIniString(smode[mode], "PortOut", "COM2", cfgName);
		p.baudIn[imode[mode]] = getIniInt(smode[mode], "BaudIn", 57600, cfgName);
		p.baudOut[imode[mode]] = getIniInt(smode[mode], "BaudOut", 57600, cfgName);
	}

	p.fwFileName = getIniString("General", "Firmware", "", cfgName);
	p.eepromFileName = getIniString("General", "EEPROM", "", cfgName);
	p.eepromSaveFileName = getIniString("General", "BurnToFile", "dump_eeprom.bin", cfgName);
	p.logFileName = getIniString("General", "LogFile", "", cfgName);
	p.options = getIniString("General", "Options", "", cfgName);

	p.afrFileName[0] = getIniString("Lambda", "NarrowAFRFile", "narrow-afr.csv", cfgName);
	p.afrFileName[1] = getIniString("Lambda", "WideAFRFile", "wide-afr.csv", cfgName);
	p.emulateWide = getIniInt("Lambda", "EmulateWide", 1, cfgName) == 1;
	p.setAfrTarget = getIniInt("Lambda", "SetAfrTarget", 1, cfgName) == 1;
	p.showSliderEgo = getIniInt("Lambda", "ShowSlider", 0, cfgName) == 1;
	p.showSliderAfr = getIniInt("Lambda", "ShowSliderAfr", 0, cfgName) == 1;
	p.stoich[0] = getIniDouble("Lambda", "StoichGasoline", -1, cfgName);
	p.stoich[1] = getIniDouble("Lambda", "StoichGas", -1, cfgName);
	if (p.stoich[0] < 0)
		p.stoich[0] = getIniDouble("Lambda", "Stoich", 14.7, cfgName);
	if (p.stoich[1] < 0)
		p.stoich[1] = getIniDouble("Lambda", "Stoich", 15.67, cfgName);

	p.saveTimePeriod = (double)getIniInt("General", "SaveTimePeriod", 60, cfgName);
	p.s3ConnectionTimeout = (double)getIniInt("General", "S3ConnectionTimeout", 4, cfgName);
	p.noLogs = getIniInt("General", "NoLogs", 0, cfgName) == 1;

    return p;
}

void writeParams(const std::string & fname, const s3emul_params & p)
{
	static const char *smode[] = { "MS", "SECU", nullptr };
	static const Mode imode[] = { Ms, Secu };

	log("Writing params to %s...\n", fname.c_str());
	std::string cfgName = openIni(fname);

	for (int mode = 0; smode[mode] != nullptr; mode++)
	{
		if (mode != Secu)
		{
			setIniString(smode[mode], "PortIn", p.portIn[imode[mode]], cfgName);
			setIniInt(smode[mode], "BaudIn", p.baudIn[imode[mode]], cfgName);
		}
		setIniString(smode[mode], "PortOut", p.portOut[imode[mode]], cfgName);
		setIniInt(smode[mode], "BaudOut", p.baudOut[imode[mode]], cfgName);
	}

	setIniString("General", "Firmware", p.fwFileName, cfgName);
	setIniString("General", "EEPROM", p.eepromFileName, cfgName);
	setIniString("General", "BurnToFile", p.eepromSaveFileName, cfgName);
	setIniString("General", "LogFile", p.logFileName, cfgName);
	setIniString("General", "Options", p.options, cfgName);

	setIniString("Lambda", "NarrowAFRFile", p.afrFileName[0], cfgName);
	setIniString("Lambda", "WideAFRFile", p.afrFileName[1], cfgName);
	setIniInt("Lambda", "EmulateWide", p.emulateWide ? 1 : 0, cfgName);
	setIniInt("Lambda", "SetAfrTarget", p.setAfrTarget ? 1 : 0, cfgName);
	setIniInt("Lambda", "ShowSlider", p.showSliderEgo ? 1 : 0, cfgName);
	setIniInt("Lambda", "ShowSliderAfr", p.showSliderAfr ? 1 : 0, cfgName);
	setIniInt("Lambda", "StoichGasoline", p.stoich[0], cfgName);
	setIniInt("Lambda", "StoichGas", p.stoich[1], cfgName);

	setIniInt("General", "SaveTimePeriod", p.saveTimePeriod, cfgName);
	setIniInt("General", "S3ConnectionTimeout", p.s3ConnectionTimeout, cfgName);
	//setIniInt("General", "NoLogs", p.noLogs ? 1 : 0, cfgName);
}

bool readCSVFile(const std::string & fileName, std::vector<CSVRecord> & csvRecords, double *duration)
{
    std::ifstream fp(fileName);
    if (fp.fail())
        return false;
    std::string line;

    double time0 = -1.0;
    double prevTime = -1.0, startTime = 0.0;

    while (std::getline(fp, line))
    {
        CSVRecord rec;
        // parse - regex is too slow :(
        char *str = (char *)line.c_str();
        char *s0 = str;
        for (int i = 0; *str != '\0'; i++)
        {
            for (; *str != '\0' && *str != ',' && *str != ' '; str++)
                ;
            if (*str != '\0')
                *str++ = '\0';
            const char *match = s0;
            for (; *str != '\0' && (*str == ',' || *str == ' '); str++)
                ;
            s0 = str;

            assert(i < maxNumFields);
            rec.fields[i] = (double)atof(match);

            if (i == 0 && duration != nullptr)  // time
            {
                int t_h, t_m, t_s, t_cs;
                sscanf(match, "%d:%d:%d.%d", &t_h, &t_m, &t_s, &t_cs);
                rec.time = (double)t_h * 3600.0 + (double)t_m * 60.0 + (double)t_s + (double)t_cs / 100.0;
                if (time0 < 0)
                    time0 = rec.time;
                rec.time -= time0;
                if (prevTime < 0)
                {
                    prevTime = rec.time;
                    startTime = rec.time;
                }
				else if (abs(rec.time - prevTime) < 0.00001)
					continue;

                // if clock starts over or if there's a big delay between records - timeshift!
				if (rec.time < prevTime || rec.time > prevTime + maxDeltaTime)
                {
                    double newTime = prevTime + 0.1;
                    time0 += rec.time - newTime;
                    rec.time = newTime;
                }

                prevTime = rec.time;
            }
        }
        csvRecords.push_back(rec);

		if (getExiting())
			break;
    }

    if (duration != nullptr)
        *duration = (prevTime - startTime);

    return true;
}

bool saveToLog(Mode mode, const std::string & str)
{
	const char *fNames[] = { "log_ms.log", "log_secu.log", "log_test.log" };
	std::ofstream fp(fNames[mode], std::fstream::in | std::fstream::out | std::fstream::app);
	if (fp.fail())
		return false;
	fp << str;
	fp.close();
	return true;
}

///////////////////////////////////////////////////////////////////////

void printHelp()
{
	log(S3EMUL_TITLE S3EMUL_DESC S3EMUL_VERSION S3EMUL_GPL "\n\n");

	log("Invalid arguments!\n");
	log("Usage: s3emul <MODE> [params.cfg]\n");
	log("\t\tMODE = \"secu\", \"ms\"\n");
	log("\n");
}








/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////


int s3Main(Mode mode)
{
#if USE_VSPE || USE_VSP
	if (!initVirtualPort(p.portBoardExt, p.portBoardInt))
		return -3;
#endif

	char timbuf[80];
	time_t tim = time(nullptr);
	strftime(timbuf, sizeof(timbuf), "\n[%Y-%m-%d %X] ", localtime(&tim));
	std::string datetime(timbuf);
	log("%s %s\n\n", datetime.c_str(), S3EMUL_TITLE " " S3EMUL_VERSION "\n" S3EMUL_GPL);

	s3emul_params p = readParams(paramsFile);

    switch (mode)
    {
	case Ms:
		emulMS(p);
		break;
	case Secu:
		emulS3(p);
		break;
	case Test:
		testPortBridge(p);
		break;
    }

#if USE_VSPE || USE_VSP
    deInitVirtualPort();
#endif

	log("Exiting!\n");

    return 0;
}

// left for console mode compatibility...
int main(int argc, char *argv[])
{
#if 0
	printf("* sizeof(inpram)=%d\n", sizeof(inpram));
	printf("* sizeof(in2ram)=%d\n", sizeof(in2ram));
	printf("* sizeof(outpc)=%d\n", sizeof(outpc));
#endif

	if (argc < 2)
	{
		printHelp();
		return -1;
	}

	char *cmdMode = argv[1];
	if (_stricmp(cmdMode, "secu") == 0)
		mode = Secu;
	else if (_stricmp(cmdMode, "ms") == 0)
		mode = Ms;
	else
	{
		printHelp();
		return -1;
	}

	if (argc > 2)
		paramsFile = argv[2];

	s3Main(mode);
}

